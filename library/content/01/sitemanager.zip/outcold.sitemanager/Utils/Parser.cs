﻿using System;
using System.Globalization;

namespace outcold.sitemanager.Utils
{
	public static class Parser
	{
		public static string GetString(object o)
		{
			if (o == null)
				return null;

			return o.ToString();
		}

		public static string GetString(object o, int lenght)
		{
			if (o == null)
				return null;

			string str = o.ToString();
			return str.Length > lenght ? str.Substring(0, lenght) : str;
		}

		public static int? GetInt(object o)
		{
			if (o == null)
				return null;

			string i = o.ToString();
			if (string.IsNullOrEmpty(i))
				return null;

			int integer;
			if (int.TryParse(i, out integer))
				return integer;

			return null;
		}

		public static decimal? GetDecimal(object o)
		{
			if (o == null)
				return null;

			string i = o.ToString();
			if (string.IsNullOrEmpty(i))
				return null;

			decimal dec;
			if (decimal.TryParse(i, out dec))
				return dec;

			return null;
		}

		public static bool? GetBool(object o)
		{
			if (o == null)
				return null;

			string i = o.ToString();
			if (string.IsNullOrEmpty(i))
				return null;

			bool value;
			if (bool.TryParse(i, out value))
				return value;

			return null;
		}

		public static DateTime? GetDate(object o)
		{
			if (o is DateTime?)
				return o as DateTime?;

			if (o is DateTime)
				return (DateTime)o;

			string val = o.ToString();

			if (!string.IsNullOrEmpty(val))
			{
				DateTime date;
				if (DateTime.TryParse(val, new CultureInfo("ru-Ru"), DateTimeStyles.None, out date))
				{
					return date;
				}
			}
			return null;
		}
	}
}