﻿using System;
using outcold.sitemanager;
using outcold.sitemanager.HTTP;
using SampleWebApplication.Domain;

namespace SampleWebApplication.Pages.Catalog
{
    public partial class Catalog : UAVDefaultPage
    {
    	private int? _firmID;
    	
		protected int? FirmID
    	{
    		get
    		{
    			if (!_firmID.HasValue)
    			{
    				_firmID = HttpContextHelper.GetInt32("firmID");
    			}
    			return _firmID;
    		}
    	}

        private int? _categoryID;

        protected int? CategoryID
        {
            get
            {
                if (!_categoryID.HasValue)
                {
                    _categoryID = HttpContextHelper.GetInt32("categoryID");
                }
                return _categoryID;
            }
        }

		private Firm _firm;

		protected Firm Firm
		{
			get
			{
				if (_firm == null && FirmID.HasValue)
				{
					_firm = Firm.Find(FirmID.Value);
				}
				return _firm;
			}
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			gridItems.PagerSettings.FirstPageImageUrl = NavigationManager.GetSiteUrl("/Resources/img/bg_bullet_arrow.gif");
			gridItems.PagerSettings.LastPageImageUrl = NavigationManager.GetSiteUrl("/Resources/img/bg_bullet_arrow_.gif");

			if (FirmID.HasValue)
			{
				MasterPage.Title = string.Format("{1}: {0}", NavigationManager.Current.CurrentItem.Title, Firm.Name);
			}
			
			dsItems.SelectParameters["categoryID"].DefaultValue = (CategoryID.HasValue ? CategoryID.Value : 0).ToString();
			dsItems.SelectParameters["firmID"].DefaultValue = (FirmID.HasValue ? FirmID.Value : 0).ToString();
			dsItems.SelectParameters["showAll"].DefaultValue = Domain.User.IsAdmin.ToString();
		}
    }
}