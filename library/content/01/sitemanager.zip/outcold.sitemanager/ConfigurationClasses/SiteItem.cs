﻿using System.Xml.Serialization;

namespace outcold.sitemanager.ConfigurationClasses
{
    public sealed class SiteItem : ConfigurationItemBase, IPatternItem
    {
        [XmlAttribute]
        public string Pattern { get; set; }

        [XmlAttribute]
        public string Location { get; set; }

        [XmlAttribute]
        public string Title { get; set; }

        [XmlElement]
        public ItemContextParameter ContextParameter { get; set; }

		[XmlElement("Parameter")]
		public ItemParameter[] Parameters { get; set; }
    }
}
