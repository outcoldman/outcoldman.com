﻿using System;
using outcold.sitemanager;
using outcold.sitemanager.HTTP;
using outcold.sitemanager.Utils;
using SampleWebApplication.Domain;

namespace SampleWebApplication.Pages.Admin
{
    public partial class CategoriesEdit : UAVDefaultPage
    {
        private int? _id;

        protected int? ParentID
        {
            get
            {
                if (!_id.HasValue)
                {
                    _id = HttpContextHelper.GetInt32("id");
                }
                return _id;
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

        	wgMasterDetails.ImagePath =
				NavigationManager.GetSiteUrl(ConfigurationUtil.GetSettings("WGImagePath", "Resources/WGImages/"));

            dsFirms.SelectCommand = string.Format("select categoryID, [name] from Category where {0}",
                                                  ParentID.HasValue ? string.Format("parentID = {0}", ParentID.Value) : "parentID is null");

			lblError.Text = MessageManager.Current.GetMessage("CannotDeleteRecord");
			lblError.Visible = false;
        }

        protected void btnGoBack_Click(object sender, EventArgs e)
        {
            if (ParentID.HasValue)
            {
				Category c = Category.Find(ParentID.Value);
                if (c != null)
                {
                    if (c.Parent != null)
                        NavigationManager.GoToUrl(
                            NavigationManager.Current.GetUrl("SampleWebApplication.categories.parent.edit", c.Parent.ID));
                    else
                        NavigationManager.GoToUrl(
                            NavigationManager.Current.GetUrl("SampleWebApplication.categories.edit"));
                }
            }
            else
            {
                NavigationManager.GoToUrl(NavigationManager.Current.GetUrl(HttpContextHelper.GetString("BackUrlItemID")));
            }
        }

		protected void DeleteRecord(object sender, WebGrid.Events.BeforeDeleteEventArgs e)
		{
			Category category = Category.Find(Parser.GetInt(e.CurrentId).Value);
			if (category != null)
			{
				try
				{
					category.DeleteAndFlush();
				}
				catch (Exception exp)
				{
					lblError.Visible = true;
					Log4NetHelper.Log.Error(exp);
				}
			}
			e.AcceptChanges = false;
		}

		protected void UpdateRecord(object sender, WebGrid.Events.AfterUpdateInsertEventArgs e)
		{
			if (e.Update)
			{
				Category category = Category.Find(Parser.GetInt(e.DataRow["categoryID"]).Value);
				category.Name = Parser.GetString(e.DataRow["name"], 50);
				category.SaveAndFlush();
			}
			else if (e.Insert)
			{
				Category category = new Category { Name = Parser.GetString(e.DataRow["name"], 50) };
				if (ParentID.HasValue)
					category.Parent = Category.Find(ParentID.Value);
				category.SaveAndFlush();
			}
		}

		protected void GridRowEventHandler(object sender, WebGrid.Events.GridRowEventArgs e)
		{
			e[0].Value = NavigationManager.Current.GetUrl("SampleWebApplication.categories.parent.edit", e.CurrentId);
		}
    }
}
