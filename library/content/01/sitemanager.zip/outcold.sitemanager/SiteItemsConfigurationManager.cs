﻿using System;
using System.IO;
using System.Xml.Serialization;
using outcold.sitemanager.ConfigurationClasses;

namespace outcold.sitemanager
{
    internal static class SiteItemsConfigurationManager
    {
        private const string _key = "SiteItemConfiguration";

        public static Configuration GetConfiguration(string location)
        {
            Log4NetHelper.Log.InfoFormat("Load Configuration: {0}", location);
            using (FileStream stream = new FileStream(location, FileMode.Open, FileAccess.Read))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(Configuration));
                object obj = serializer.Deserialize(stream);
                return obj as Configuration;
            }
        }

        public static Configuration GetConfiguration()
        {
            string location = System.Configuration.ConfigurationManager.AppSettings.Get(_key);
            return GetConfiguration(AppDomain.CurrentDomain.BaseDirectory + location);
        }
    }
}