﻿using System;
using System.Windows.Input;

namespace SilverlightValidation
{
	public class DelegateCommand : ICommand
	{
		private readonly Action<object> _execute;
		private readonly Func<object, bool> _canExecute;

		public DelegateCommand(Action<object> execute)
		{
			if (execute == null)
				throw new ArgumentNullException("execute");
			_execute = execute;
		}

		public DelegateCommand(Action<object> execute, Func<object, bool> canExecute)
			: this(execute)
		{
			if (canExecute == null)
				throw new ArgumentNullException("canExecute");
			_canExecute = canExecute;
		}

		public bool CanExecute(object parameter)
		{
			if (_canExecute != null)
				return _canExecute(parameter);
			return true;
		}

		public void Execute(object parameter)
		{
			_execute(parameter);
		}

		public void RaiseCanExecuteChanged()
		{
			CanExecuteChanged(this, EventArgs.Empty);
		}

		public event EventHandler CanExecuteChanged = delegate {};
	}
}
