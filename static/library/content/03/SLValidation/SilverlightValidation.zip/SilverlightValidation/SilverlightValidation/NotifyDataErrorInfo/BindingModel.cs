﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Windows;

namespace SilverlightValidation.NotifyDataErrorInfo
{
	public class BindingModel : BindingModelBase<BindingModel>
	{
		private string _newPassword;
		private string _newPasswordConfirmation;

		public DelegateCommand ChangePasswordCommand { get; private set; }

		public BindingModel()
		{
			ChangePasswordCommand = new DelegateCommand(ChangePassword);

			AddAllAttributeValidators();

			//AddValidationFor(() => NewPassword)
			//    .When(x => string.IsNullOrEmpty(x._newPassword))
			//    .Show("New password required field.");

			//AddValidationFor(() => NewPassword)
			//    .When(x => !string.IsNullOrEmpty(x._newPassword) && x._newPassword.Length > 80)
			//    .Show("New password must be a string with maximum length of 80.");

			AddValidationFor(() => NewPasswordConfirmation)
				.When(x => !string.IsNullOrEmpty(x._newPassword) && string.CompareOrdinal(x._newPassword, x._newPasswordConfirmation) != 0)
				.Show("Password confirmation not equal to password.");
		}

		[Display(Name = "New password")]
		[Required]
		[StringLength(80, ErrorMessage = "New password must be a string with maximum length of 80.")]
		public string NewPassword
		{
			get { return _newPassword; }
			set
			{
				_newPassword = value;
				OnCurrentPropertyChanged();
			}
		}

		[Display(Name = "New password confirmation")]
		public string NewPasswordConfirmation
		{
			get { return _newPasswordConfirmation; }
			set
			{
				_newPasswordConfirmation = value;
				OnCurrentPropertyChanged();
			}
		}

		private void ChangePassword(object obj)
		{
			ValidateAll();

			if (!HasErrors)
			{
				MessageBox.Show("Bingo!");
			}
		}
	}
}