﻿using System.Data;
using System.Data.SqlClient;
using Castle.ActiveRecord;
using outcold.sitemanager.DataAccess;

namespace SampleWebApplication.Domain
{
    /// <summary>
    /// Класс валют
    /// </summary>
    [ActiveRecord]
    public class Currency : HttpActiveRecordBase<Currency>
    {
        [PrimaryKey("currencyID")]
        public int? ID { get; set; }

        [Property]
        public string Name { get; set; }

        /// <summary>
        /// Get Currencies for DropDownList
        /// </summary>
        /// <returns>Table(currencyID,name)</returns>
        public static DataTable GetCurrencies()
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = DataAccessor.SqlConnection)
            {
                connection.Open();
                SqlDataAdapter a = new SqlDataAdapter(@"exec CurrenciesDropDownList", connection);
                a.Fill(dt);
                connection.Close();
            }
            return dt;
        }
    }
}