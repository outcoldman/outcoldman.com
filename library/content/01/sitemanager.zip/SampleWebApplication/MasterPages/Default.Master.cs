﻿using System;
using System.Web.UI;
using outcold.sitemanager;
using SampleWebApplication.Domain;

namespace SampleWebApplication.MasterPages
{
    public partial class Default : MasterPage
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            loginStatus.Visible = Request.IsAuthenticated;
            loginStatus.LogoutPageUrl = NavigationManager.Current.GetUrl("SampleWebApplication.default");
        	menuAdmin.Visible = User.IsAdmin;
        }

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);

            //Установка заголовка окна
			Page.Title = string.Format("{0}: {1}", Page.Title, GetTitle());
		}

        protected string GetTitle()
        {
			if (!string.IsNullOrEmpty(Title))
				return Title;
            if (NavigationManager.Current != null && NavigationManager.Current.CurrentItem != null)
                return NavigationManager.Current.CurrentItem.Title;
            return string.Empty;
        }

        public string Title { get; set; }
    }
}