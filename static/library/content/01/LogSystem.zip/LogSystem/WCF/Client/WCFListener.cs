﻿using System;
using System.Security.Cryptography;
using System.Text;
using LogSystem.Security;

namespace LogSystem.WCF.Client
{
    //TODO: Maybe need singly methods for connect and disconnect
    //TODO: Connect Async
    public class WCFListener : IWCFLoggerOutputCallback, IDisposable
    {
        private RSAParameters? RSAParameters { get; set; }
        private WCFClient Client { get; set; }

        public WCFListener(string endPoint, bool fSecurity)
        {
            Client = new WCFClient(this, endPoint);

            if (fSecurity)
            {
                using (RSACryptoServiceProvider rsa = new RSACryptoServiceProvider())
                {
                    RSAParameters = rsa.ExportParameters(true);
                    Client.RegisterListener(rsa.ExportParameters(false));
                }
            }
            else
            {
                Client.RegisterListener();
            }
        }

        public bool IsSecure
        {
            get { return RSAParameters.HasValue; }
        }

        // TODO: Change Action delegate to friendly name delegate
        public event Action<string> Log;

        void IWCFLoggerOutputCallback.Log(byte[] message)
        {
            if (IsSecure)
            {
                message = RSAHelper.Decrypt(message, RSAParameters.Value);
            }

            //TODO: customize encoding
            string sMessage = Encoding.Unicode.GetString(message);

            if (Log != null)
                Log(sMessage);
        }

        public void Dispose()
        {
            Client.CloseChannel();
            Client.Close();
        }
    }
}