﻿using System.IO;
using System.Net;
using System.ServiceProcess;
using System.Timers;
using LinqToTwitter;

namespace WindowsServiceIPPublicator
{
    public partial class IPPublicatorService : ServiceBase
    {
        private readonly Timer _timer;

        public IPPublicatorService()
        {
            InitializeComponent();

            _timer = new Timer {Enabled = false};
            _timer.Elapsed += TwittIpAddress;
            // Each hour (3600 seconds, 60 minutes)
            _timer.Interval = 3600000;
        }

        private static void TwittIpAddress(object sender, ElapsedEventArgs e)
        {
            UsernamePasswordAuthorization auth = new UsernamePasswordAuthorization
                                                     {
                                                         UserName = "UserName",
                                                         Password = "Password"
                                                     };

            // Основной провайдер для работы с twitter
            TwitterContext twitterCtx = new TwitterContext(auth);
            // Осуществляем авторизацию
            auth.SignOn();

            string message = string.Format("My IP Address is: {0}", GetIpAddress());

            //Пишем новый tweet
            twitterCtx.UpdateStatus(message);

            //Отправляем сообщение на аккаунт
            twitterCtx.NewDirectMessage("ToUserName", message);

            auth.SignOff();
        }

        private static string GetIpAddress()
        {
            WebClient myWebClient = new WebClient();
            Stream myStream = myWebClient.OpenRead("http://www.geekpedia.com/ip.php");
            StreamReader myStreamReader = new StreamReader(myStream);
            return myStreamReader.ReadToEnd();
        }

        protected override void OnStart(string[] args)
        {
            _timer.Enabled = true;
        }

        protected override void OnStop()
        {
            _timer.Enabled = false;
        }
    }
}