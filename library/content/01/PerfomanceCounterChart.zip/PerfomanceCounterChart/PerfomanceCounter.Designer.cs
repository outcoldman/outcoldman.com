﻿namespace PerfomanceCounterChart
{
	partial class PerfomanceCounter
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			DisposeCounters();
			DisposeThread();
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
			System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
			System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
			System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
			this.chartPerfomance = new System.Windows.Forms.DataVisualization.Charting.Chart();
			((System.ComponentModel.ISupportInitialize)(this.chartPerfomance)).BeginInit();
			this.SuspendLayout();
			// 
			// chartPerfomance
			// 
			this.chartPerfomance.BackColor = System.Drawing.Color.SteelBlue;
			this.chartPerfomance.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.DiagonalRight;
			this.chartPerfomance.BackSecondaryColor = System.Drawing.Color.White;
			this.chartPerfomance.BorderSkin.SkinStyle = System.Windows.Forms.DataVisualization.Charting.BorderSkinStyle.Sunken;
			chartArea1.Area3DStyle.Enable3D = true;
			chartArea1.Area3DStyle.Inclination = 40;
			chartArea1.Area3DStyle.IsClustered = true;
			chartArea1.Area3DStyle.IsRightAngleAxes = false;
			chartArea1.Area3DStyle.LightStyle = System.Windows.Forms.DataVisualization.Charting.LightStyle.Realistic;
			chartArea1.Area3DStyle.Perspective = 20;
			chartArea1.Area3DStyle.PointDepth = 200;
			chartArea1.Area3DStyle.PointGapDepth = 200;
			chartArea1.AxisY.Maximum = 100;
			chartArea1.AxisY.Minimum = 0;
			chartArea1.AxisY.ScaleBreakStyle.BreakLineStyle = System.Windows.Forms.DataVisualization.Charting.BreakLineStyle.Wave;
			chartArea1.AxisY.ScaleBreakStyle.Enabled = true;
			chartArea1.AxisY.ScaleBreakStyle.LineColor = System.Drawing.Color.Lime;
			chartArea1.BackColor = System.Drawing.Color.LightBlue;
			chartArea1.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.Center;
			chartArea1.BackSecondaryColor = System.Drawing.Color.White;
			chartArea1.BorderColor = System.Drawing.Color.Empty;
			chartArea1.InnerPlotPosition.Auto = false;
			chartArea1.InnerPlotPosition.Height = 88.48166F;
			chartArea1.InnerPlotPosition.Width = 90.2958F;
			chartArea1.InnerPlotPosition.X = 8.5382F;
			chartArea1.InnerPlotPosition.Y = 2.35462F;
			chartArea1.Name = "ChartArea1";
			chartArea1.ShadowColor = System.Drawing.Color.Empty;
			this.chartPerfomance.ChartAreas.Add(chartArea1);
			this.chartPerfomance.Dock = System.Windows.Forms.DockStyle.Fill;
			this.chartPerfomance.Location = new System.Drawing.Point(0, 0);
			this.chartPerfomance.Name = "chartPerfomance";
			series1.ChartArea = "ChartArea1";
			series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
			series1.Color = System.Drawing.Color.Red;
			series1.Name = "Series1";
			series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
			series1.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;
			series2.ChartArea = "ChartArea1";
			series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
			series2.Color = System.Drawing.Color.Blue;
			series2.Name = "Series2";
			series2.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
			series2.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;
			series3.ChartArea = "ChartArea1";
			series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
			series3.Color = System.Drawing.Color.White;
			series3.Name = "Series3";
			series3.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
			series3.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;
			this.chartPerfomance.Series.Add(series1);
			this.chartPerfomance.Series.Add(series2);
			this.chartPerfomance.Series.Add(series3);
			this.chartPerfomance.Size = new System.Drawing.Size(662, 484);
			this.chartPerfomance.TabIndex = 0;
			this.chartPerfomance.Text = "chartPerfomance";
			this.chartPerfomance.MouseUp += new System.Windows.Forms.MouseEventHandler(this.chartPerfomance_MouseUp);
			this.chartPerfomance.MouseMove += new System.Windows.Forms.MouseEventHandler(this.chartPerfomance_MouseMove);
			this.chartPerfomance.MouseDown += new System.Windows.Forms.MouseEventHandler(this.chartPerfomance_MouseDown);
			// 
			// PerfomanceCounter
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(662, 484);
			this.Controls.Add(this.chartPerfomance);
			this.Name = "PerfomanceCounter";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.chartPerfomance)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.DataVisualization.Charting.Chart chartPerfomance;
	}
}

