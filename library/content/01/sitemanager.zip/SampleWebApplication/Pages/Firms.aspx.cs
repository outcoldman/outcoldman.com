﻿namespace SampleWebApplication.Pages
{
    /// <summary>
    /// Страница отображения фирм
    /// </summary>
    public partial class Firms : UAVDefaultPage
    {
        protected int index = 0;

        protected override void OnLoad(System.EventArgs e)
        {
            base.OnLoad(e);

            //Показывать все фирмы (и не активные) только администратору
            dsFirms.SelectParameters["onlyActive"].DefaultValue = (!Domain.User.IsAdmin).ToString();
        }
    }
}