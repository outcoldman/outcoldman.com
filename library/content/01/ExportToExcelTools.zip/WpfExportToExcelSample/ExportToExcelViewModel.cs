﻿using System;
using System.Collections.ObjectModel;

namespace ExportToExcelSample
{
  public class ExportToExcelViewModel
  {
    public ObservableCollection<Person> Persons
    {
      get
      {
        ObservableCollection<Person> collection = new ObservableCollection<Person>();
        for (int i = 0; i < 100; i++)
          collection.Add(new Person()
          {
            Name = "Person Name " + i,
            Surname = "Person Surname " + i,
            DateOfBirth = DateTime.Now.AddDays(i)
          });
        return collection;
      }
    }
  }
}