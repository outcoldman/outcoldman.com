﻿namespace outcold.sitemanager.ConfigurationClasses
{
    public interface IUserAccessListItem
    {
        User[] Users { get; set; }
    }
}