﻿using System;
using System.Collections.Generic;
using NHibernateTestConsoleApplication.Core.DAL;
using NHibernateTestConsoleApplication.Core.Domain;

namespace NHibernateTestConsoleApplication
{
	class Program
	{
		static void Main(string[] args)
		{
			Configuration.ReConfigurate();
			Configuration.Current.AddAssembly(typeof(User).Assembly);

			IList<User> users;
			using (DataContext dataContext = new DataContext())
			{
				users = dataContext.CurrentSession.CreateCriteria<User>().List<User>();
			}

			foreach (User user in users)
			{
				Console.WriteLine("User - {0}, Name - {1}, Surname - {2}", user.Id, user.Name, user.Surname);
			}

			Console.ReadKey();
		}
	}
}
