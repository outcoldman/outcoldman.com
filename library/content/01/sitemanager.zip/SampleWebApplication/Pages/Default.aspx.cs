﻿namespace SampleWebApplication.Pages
{
    /// <summary>
    /// Главная страница приложения
    /// </summary>
    public partial class Default : UAVDefaultPage
    {
    }
}