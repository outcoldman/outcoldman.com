﻿using System.Web;
using System.Xml.Serialization;

namespace outcold.sitemanager.ConfigurationClasses
{
    public abstract class ConfigurationItemBase : IConfigurationItem, IUserAccessListItem
    {
        [XmlAttribute]
        public string Id { get; set; }

        [XmlElement("User")]
        public User[] Users { get; set; }

        public bool IsUserAllowed()
        {
            if (Users == null || Users.Length <= 0)
                return true;

            if (HttpContext.Current != null && HttpContext.Current.Request.IsAuthenticated && HttpContext.Current.User != null)
            {
                foreach (User user in Users)
                {
                    if (string.Compare(user.Name, HttpContext.Current.User.Identity.Name) == 0)
                        return true;
                }
            }
            return false;
        }
    }
}
