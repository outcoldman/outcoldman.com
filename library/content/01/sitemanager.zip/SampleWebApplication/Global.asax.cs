﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using outcold.sitemanager;
using outcold.sitemanager.DataAccess;
using outcold.sitemanager.HTTP;
using outcold.sitemanager.Utils;
using SampleWebApplication.Domain;

namespace SampleWebApplication
{
    public class Global : SiteManagerHTTPApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            if (!ActiveRecordManager.Initialized) ActiveRecordManager.Initialize(Assembly.GetExecutingAssembly());

            StatisticManager.OnSessonStart -= StatisticManager_OnSessonStart;
            StatisticManager.OnSessonStart += StatisticManager_OnSessonStart;

            StatisticManager.OnRequestLog -= StatisticManager_OnRequestLog;
            StatisticManager.OnRequestLog += StatisticManager_OnRequestLog;
        }

        /// <summary>
        /// Запись статистики по сессиям
        /// </summary>
        /// <param name="context"></param>
        /// <param name="botID"></param>
        /// <param name="seID"></param>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public int? StatisticManager_OnSessonStart(System.Web.HttpContext context, int? botID, int? seID, string keyword)
        {
            if (context.User.Identity.IsAuthenticated
                && !ConfigurationUtil.GetBoolSettings("LogAdminSteps", false))
                return null;

            try
            {
                using (SqlConnection connection = new SqlConnection(DataAccessor.SqlConnection.ConnectionString))
                {
                    using (
                        SqlCommand cmd = new SqlCommand("StatisticStartSession", connection) {CommandType = CommandType.StoredProcedure})
                    {
                        cmd.Parameters.AddWithValue("@UserID", Parser.GetString(context.User.Identity.Name, 10));
                        cmd.Parameters.AddWithValue("@IPAddress", Parser.GetString(context.Request.UserHostAddress, 15));
                        cmd.Parameters.AddWithValue("@BrowserString", context.Request.UserAgent ?? string.Empty);
                        if (context.Request.UrlReferrer != null)
                            cmd.Parameters.AddWithValue("@ReferralURL", context.Server.UrlDecode(context.Request.UrlReferrer.ToString()));
                        if (ConfigurationUtil.SitestatParseAddData)
                        {
                            if (botID.HasValue)
                                cmd.Parameters.AddWithValue("@BotID", botID.Value);
                            if (seID.HasValue)
                                cmd.Parameters.AddWithValue("@SearchEngineID", seID.Value);
                            if (!string.IsNullOrEmpty(keyword))
                                cmd.Parameters.AddWithValue("@Keyword", keyword);
                            if (context.Request.UrlReferrer != null && !string.IsNullOrEmpty(context.Request.UrlReferrer.Host))
                                cmd.Parameters.AddWithValue("@SiteName", context.Request.UrlReferrer.Host);
                        }
                        cmd.Parameters.Add("@sessionID", SqlDbType.Int).Direction = ParameterDirection.Output;
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        return Parser.GetInt(cmd.Parameters["@sessionID"].Value).Value;
                    }
                }
            }
            catch(Exception e)
            {
                Log4NetHelper.Log.Error(e);
            }
            return null;
        }

        /// <summary>
        /// запись статистики по request (запросам страниц)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sessionID"></param>
        public void StatisticManager_OnRequestLog(System.Web.HttpContext context, int sessionID)
        {
            if (context == null || context.Session == null || string.Compare(context.Request.HttpMethod, "POST") == 0)
                return;

            if (context.User.Identity.IsAuthenticated
                && !ConfigurationUtil.GetBoolSettings("LogAdminSteps", false))
                return;

            try
            {
                using (SqlConnection connection = new SqlConnection(DataAccessor.SqlConnection.ConnectionString))
                {
                    using (
                        SqlCommand cmd = new SqlCommand("StatisticRequestLog", connection) {CommandType = CommandType.StoredProcedure})
                    {
                        cmd.Parameters.AddWithValue("@SessionID", sessionID);
                        cmd.Parameters.AddWithValue("@PageUrl", context.Request.AppRelativeCurrentExecutionFilePath.Length > 2 
                                                                    ? context.Request.AppRelativeCurrentExecutionFilePath.Substring(2) : context.Request.AppRelativeCurrentExecutionFilePath);
                        cmd.Parameters.AddWithValue("@query", context.Request.RawUrl.IndexOf("?") > 0
                                                                  ? context.Request.RawUrl.Substring(context.Request.RawUrl.IndexOf("?") + 1) : null);
                        if (context.User.Identity.IsAuthenticated)
                            cmd.Parameters.AddWithValue("@userID", context.User.Identity.Name);

                        if (NavigationManager.Current.CurrentItem != null && NavigationManager.Current.IsWorkURL
                            && string.Compare(NavigationManager.Current.CurrentItem.Id, "uav.catalog.firm.category.item.selected", true) == 0)
                            cmd.Parameters.AddWithValue("@itemID", HttpContextHelper.GetInt32("id"));

                        connection.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch(Exception e)
            {
                Log4NetHelper.Log.Error(e);
            }
        }
    }
}