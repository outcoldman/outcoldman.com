﻿using System.Data;
using outcold.sitemanager.Utils;

namespace SampleWebApplication.Controls
{
    /// <summary>
    /// Контрол для отображения категорий
    /// </summary>
    public partial class CategoryFoldersCtl : CatalogCtlBase
    {
        protected static int GetDepth(object obj)
        {
            return Parser.GetInt(((DataRowView) obj)["depth"]).Value;
        }

        protected override void OnLoad(System.EventArgs e)
        {
            base.OnLoad(e);

            if (FirmID.HasValue)
                dsCategories.SelectParameters["firmID"].DefaultValue = FirmID.Value.ToString();
        }
    }
}