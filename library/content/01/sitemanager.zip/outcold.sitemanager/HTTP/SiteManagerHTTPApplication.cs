﻿using System;

using System.Web;
using System.Web.UI;
using outcold.sitemanager.ConfigurationClasses;

namespace outcold.sitemanager.HTTP
{
    public class SiteManagerHTTPApplication : HttpApplication
    {
        public override void Init()
        {
            base.Init();
            Log4NetHelper.InitLogger();
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            Application.Lock();
            InitNavigationManager();
            InitMenuManager();
        	InitMessageManager();
        	InitStatisticManager();
            Application.UnLock();
        }

        protected void Application_PreRequestHandlerExecute(object sender, EventArgs e)
        {
            HttpApplication app = (HttpApplication)sender;
            if ((app.Context.CurrentHandler is Page) && app.Context.CurrentHandler != null)
            {
                Page pg = (Page)app.Context.CurrentHandler;
                pg.PreInit += delegate
                                  {
                                      if (HttpContext.Current.Items.Contains("OriginalUrl"))
                                      {
                                          string path = (string) HttpContext.Current.Items["OriginalUrl"];
                                          if (path.IndexOf("?") == -1) path += "?";
                                          HttpContext.Current.RewritePath(path);
                                      }
                                  };
            }
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
			NavigationManager.Current.OpenUrl(HttpContext.Current.Request.Path);
        }

		protected void Application_PostRequestHandlerExecute(object sender, EventArgs e)
		{
			if (ConfigurationUtil.GetBoolSettings("NeedStatistic", false))
				StatisticManager.Request(HttpContext.Current);
		}

    	private void InitNavigationManager()
        {
            if (Application[_keyConfiguration] == null)
            {
                Application[_keyConfiguration] = NavigationManager.Current;
            }

			NavigationManager.Init(Application[_keyConfiguration] as NavigationManager);
        }

        private void InitMenuManager()
        {
			if (Application[_keyMenuConfiguration] == null)
            {
				Application[_keyMenuConfiguration] = MenuManager.Current;
            }

			MenuManager.Init(Application[_keyMenuConfiguration] as MenuManager);
        }

		private void InitMessageManager()
		{
			if (Application[_keyMessageConfiguration] == null)
			{
				Application[_keyMessageConfiguration] = MenuManager.Current;
			}

			MenuManager.Init(Application[_keyMessageConfiguration] as MenuManager);
		}

		private void InitStatisticManager()
		{
			if (Application[_keyStatisticConfiguration] == null)
			{
				Application[_keyStatisticConfiguration] = StatisticManager.Current;
			}

			StatisticManager.Init(Application[_keyStatisticConfiguration] as StatisticManager);
		}

        private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Log4NetHelper.Log.Fatal("UnhandledException", e.ExceptionObject as Exception);
			if (NavigationManager.Current != null)
				Session[keyLastException] = e.ExceptionObject as Exception;
        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {
			if (NavigationManager.Current.IsWorkURL)
			{
				SiteItem currentItem = NavigationManager.Current.CurrentItem;
				if (currentItem == null || !NavigationManager.Current.Configuration.CheckUser(currentItem.Id))
					throw new HttpException(403, "Page not find");
			}
        }

    	protected void Application_Error(object sender, EventArgs e)
        {
            Exception error = Server.GetLastError();
            Log4NetHelper.Log.Error("Application Error", error);
            if (NavigationManager.Current != null)
				HttpContext.Current.Items.Add(keyLastException, error);
        }
        
        private const string _keyConfiguration = "SiteManagerHTTPApplication_Configuration";
		private const string _keyMessageConfiguration = "SiteManagerHTTPApplication_MessageConfiguration";
		private const string _keyStatisticConfiguration = "SiteManagerHTTPApplication_StatisticConfiguration";
		private const string _keyMenuConfiguration = "SiteManagerHTTPApplication_MenuConfiguration";
    	public const string keyLastException = "SiteManagerHTTPApplication_LastException";
    }
}