﻿using System;
using System.Drawing;
using System.IO;
using System.Web.UI;
using outcold.sitemanager;
using outcold.sitemanager.HTTP;
using outcold.sitemanager.Utils;
using SampleWebApplication.Domain;

namespace SampleWebApplication.Pages.Admin
{
    public partial class ItemEdit : UAVDefaultPage
    {
		private int? _id;

		protected int? ItemID
		{
			get
			{
				if (!_id.HasValue)
				{
					_id = HttpContextHelper.GetInt32("id");
				}
				return _id;
			}
		}

		private Item _item;

		protected Item Item
		{
			get
			{
				if (_item == null && ItemID.HasValue)
				{
					_item = Item.Find(ItemID.Value);
				}
				return _item;
			}
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			if (!IsPostBack)
			{
				InitCategories();
				InitFirms();
				InitCurrency();
				InitItem();
			}

			btnDelete.Visible = ItemID.HasValue;
		}

    	private void InitItem()
    	{
			if (ItemID.HasValue && Item != null)
			{
				tbTitle.Text = Item.Title;
				fckBody.Value = Item.Body;
				chkIsActive.Checked = Item.IsActive;
				ddlCategories.SelectedValue = Item.Category.ID.ToString();
				ddlFirms.SelectedValue = Item.Firm.ID.ToString();
				if (Item.Currency != null)
					ddlCurrency.SelectedValue = Item.Currency.ID.ToString();
				tbPrice.Text = string.Format("{0:F}", Item.Price);
				hiddenImgPath.Value = Item.ImagePath;
				imgItem.Src = NavigationManager.GetSiteUrl(Item.ImagePath);
				imgItem.Visible = !string.IsNullOrEmpty(Item.ImagePath);
				btnDelImage.Visible = !string.IsNullOrEmpty(Item.ImagePath);
			}
    	}

    	private void InitCategories()
    	{
			ddlCategories.DataSource = Category.GetCategories();
			ddlCategories.DataValueField = "categoryID";
			ddlCategories.DataTextField = "name";
			ddlCategories.DataBind();
    		ddlCategories.SelectedValue = string.Empty;
    	}

		private void InitFirms()
		{
			ddlFirms.DataSource = Firm.GetFirms();
			ddlFirms.DataValueField = "firmID";
			ddlFirms.DataTextField = "name";
			ddlFirms.DataBind();
			ddlFirms.SelectedValue = string.Empty;
		}

		private void InitCurrency()
		{
			ddlCurrency.DataSource = Currency.GetCurrencies();
			ddlCurrency.DataValueField = "currencyID";
			ddlCurrency.DataTextField = "name";
			ddlCurrency.DataBind();
			ddlCurrency.SelectedValue = string.Empty;
		}

    	protected void btnSave_Click(object sender, EventArgs e)
        {
    		int? firmID = Parser.GetInt(ddlFirms.SelectedValue);
    		int? categoryID = Parser.GetInt(ddlCategories.SelectedValue);
    		int? currency = Parser.GetInt(ddlCurrency.SelectedValue);

			if (!imgItem.Visible && !string.IsNullOrEmpty(hiddenImgPath.Value))
			{
				FileManager.DeleteFile(hiddenImgPath.Value);
				hiddenImgPath.Value = null;
			}

			string imgPath = uploadImg.HasFile
								? FileManager.SaveGuidFile(MessageManager.Current.GetMessage("ImageItemsPath")
															 , Path.GetExtension(uploadImg.FileName), uploadImg.FileBytes)
								: hiddenImgPath.Value;
			if (uploadImg.HasFile && !string.IsNullOrEmpty(hiddenImgPath.Value))
				FileManager.DeleteFile(hiddenImgPath.Value);

			Size s = !string.IsNullOrEmpty(imgPath) ? FileManager.GetImageSize(imgPath) : new Size();

			if (firmID.HasValue && firmID.Value > 0 && categoryID.HasValue && categoryID.Value > 0)
			{
				Item i = ItemID.HasValue ? Item.Find(ItemID.Value) : new Item();
				i.Title = tbTitle.Text;
				i.Body = fckBody.Value;
				i.Price = Parser.GetDecimal(tbPrice.Text);
				i.ImagePath = imgPath;
				i.IsActive = chkIsActive.Checked;
				if (i.Category == null || i.Category.ID != categoryID)
				{
					i.Category = Category.Find(categoryID.Value);
				}
				if (i.Firm == null || i.Firm.ID != firmID)
				{
					i.Firm = Firm.Find(firmID.Value);
				}
				if ((i.Currency == null && currency.HasValue) 
					|| (i.Currency != null && !currency.HasValue)
					|| (i.Currency != null && currency.HasValue && i.Currency.ID != currency.Value))
				{
					i.Currency = (currency.HasValue) ? Currency.Find(currency.Value) : null;
				}
				i.ImgHeight = string.IsNullOrEmpty(imgPath) ? null : (int?)s.Height;
				i.ImgWidth = string.IsNullOrEmpty(imgPath) ? null : (int?)s.Width;
				i.SaveAndFlush();
			}
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
			if (ItemID.HasValue)
			{
				Item item = Item.Find(ItemID.Value);
				FileManager.DeleteFile(item.ImagePath);
				item.DeleteAndFlush();
			}
        }

		protected void btnDelImage_Click(object sender, ImageClickEventArgs e)
		{
			if (!string.IsNullOrEmpty(hiddenImgPath.Value))
			{
				imgItem.Visible = false;
				btnDelImage.Visible = false;
			}
		}
    }
}
