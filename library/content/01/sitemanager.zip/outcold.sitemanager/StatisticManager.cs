﻿using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Web;
using System.Xml.Serialization;
using outcold.sitemanager.Statistic;
using outcold.sitemanager.Utils;

namespace outcold.sitemanager
{
	public enum PersistIDPlace
	{
		Session,
		Cookie
	}

	public class StatisticManager
	{
		private const string _key = "StatisticConfiguration";
		private const string _keysessionid = "SessionID";

		private static Statistic.Statistic GetConfiguration(string location)
		{
			Log4NetHelper.Log.InfoFormat("Load Menus: {0}", location);
			using (FileStream stream = new FileStream(location, FileMode.Open, FileAccess.Read))
			{
				XmlSerializer serializer = new XmlSerializer(typeof(Statistic.Statistic));
				object obj = serializer.Deserialize(stream);
				return obj as Statistic.Statistic;
			}
		}

		private static Statistic.Statistic GetConfiguration()
		{
			string location = System.Configuration.ConfigurationManager.AppSettings.Get(_key);
			return GetConfiguration(AppDomain.CurrentDomain.BaseDirectory + location);
		}

		#region Singleton

		private static readonly object _locker = new object();
		private static StatisticManager _current;

		private StatisticManager(Statistic.Statistic menus)
		{
			Messages = menus;
		}

		public static StatisticManager Current
		{
			get
			{
				if (_current == null)
				{
					lock (_locker)
					{
						if (_current == null)
						{
							_current = new StatisticManager(GetConfiguration());
						}
					}
				}
				return _current;
			}
		}

		internal Statistic.Statistic Messages { get; set; }

		public static StatisticManager Init(StatisticManager current)
		{
			if (_current == null)
			{
				lock (_locker)
				{
					if (_current == null)
					{
						_current = current;
					}
				}
			}
			return _current;
		}

		#endregion

		#region Log

		public delegate int? SessionStartDelegate(HttpContext context, int? botID, int? seID, string keyword);

		public static  event SessionStartDelegate OnSessonStart;

		public delegate void RequestLogDelegate(HttpContext context, int sessionID);

		public static event RequestLogDelegate OnRequestLog;

		private static int? SessionStart(HttpContext context)
		{
            try
            {
                string keyword = null;
                int? botID = null;
                int? seID = null;

                Statistic.Statistic st = GetConfiguration();

                if (ConfigurationUtil.SitestatParseAddData)
                {
                    foreach (Bot bot in st.Bots.List)
                    {
                        if (Regex.IsMatch(context.Request.UserAgent ?? string.Empty, bot.Mask,
                                          RegexOptions.Compiled | RegexOptions.IgnoreCase))
                        {
                            botID = bot.ID;
                            break;
                        }
                    }

                    if (botID.HasValue && !ConfigurationUtil.SitestatPersistBots)
                        return null;

                    if (context.Request.UrlReferrer != null &&
                        !string.IsNullOrEmpty(context.Request.UrlReferrer.ToString()))
                    {
                        foreach (SearchEngine engine in st.SearchEngines.List)
                        {
                            if (Regex.IsMatch(context.Request.UrlReferrer.ToString(), engine.Mask,
                                              RegexOptions.Compiled | RegexOptions.IgnoreCase))
                            {
                                seID = engine.ID;

                                foreach (
                                    string param in
                                        context.Server.UrlDecode(context.Request.UrlReferrer.Query).Split(new[]
                                                                                                              {'?', '&'})
                                    )
                                {
                                    if (param.StartsWith(engine.KeywordsMask))
                                    {
                                        keyword = param.Replace(engine.KeywordsMask, string.Empty);
                                        break;
                                    }
                                }
                                break;
                            }
                        }
                    }
                }

                return (OnSessonStart != null) ? OnSessonStart(context, botID, seID, keyword) : null;
            }
            catch(Exception e)
            {
                Log4NetHelper.Log.Error(e);
                return null;
            }
		}

		public static void Request(HttpContext context)
		{
		    try
		    {
                if (context == null || context.Session == null)
                    return;

                if (OnRequestLog != null)
                {
                    int? sessionID;
                    switch (ConfigurationUtil.SitestatPersistIDPlace)
                    {
                        case PersistIDPlace.Session:
                            if (context.Session[_keysessionid] != null)
                                sessionID = (int)context.Session[_keysessionid];
                            else
                            {
                                sessionID = SessionStart(context);
                                if (sessionID.HasValue)
                                    context.Session[_keysessionid] = sessionID.Value;
                            }
                            break;
                        default:
                            if (context.Request.Cookies[_keysessionid] != null)
                                sessionID = Parser.GetInt(context.Request.Cookies[_keysessionid].Value);
                            else
                            {
                                sessionID = SessionStart(context);
                                if (sessionID.HasValue)
                                    context.Response.Cookies.Add(new HttpCookie(_keysessionid, sessionID.Value.ToString()));
                            }
                            break;
                    }
                    if (!sessionID.HasValue)
                        return;

                    OnRequestLog(context, sessionID.Value);
                }
		    }
		    catch (Exception e)
		    {
		        Log4NetHelper.Log.Error(e);
		    }
		}

		#endregion

	}
}