﻿namespace LinqToTwitter
{
    public enum HttpMethod { GET, POST };
}
