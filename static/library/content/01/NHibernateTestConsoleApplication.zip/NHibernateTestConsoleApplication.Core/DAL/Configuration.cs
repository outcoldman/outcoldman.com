﻿using System.Configuration;
using NHibernate;
using NHibernate.Connection;
using NHibernate.Dialect;
using Environment = NHibernate.Cfg.Environment;

namespace NHibernateTestConsoleApplication.Core.DAL
{
	public class Configuration : global::NHibernate.Cfg.Configuration
	{
		#region Singleton

		private static readonly object _locker = new object();

		private static Configuration _config;
		private static ISessionFactory _factory;

		/// <summary>
		/// Thread safe current NHibernate configuration
		/// </summary>
		public static Configuration Current
		{
			get
			{
				if (_config == null)
				{
					lock (_locker)
					{
						if (_config == null)
						{
							CreateConfiguration();
						}
					}
				}

				return _config;
			}
		}

		/// <summary>
		/// Create Configuration of NHibernate
		/// </summary>
		public static void ReConfigurate()
		{
			if (_config != null)
			{
				lock (_locker)
				{
					if (_config != null)
					{
						CreateConfiguration();
					}
				}
			}
		}

		private static void CreateConfiguration()
		{
			_config = new Configuration();
			_config.SetProperty(Environment.ConnectionProvider, typeof(DriverConnectionProvider).FullName);
			_config.SetProperty(Environment.Dialect, typeof(MsSql2005Dialect).FullName);
			_config.SetProperty(Environment.ConnectionString, GetConnectionString());
			_config.SetProperty(Environment.Isolation, "ReadCommitted");
			_config.SetProperty(Environment.CommandTimeout, "600");
			_config.SetProperty(Environment.MaxFetchDepth, "4");
			_config.SetProperty(Environment.ProxyFactoryFactoryClass,
								"NHibernate.ByteCode.Castle.ProxyFactoryFactory, NHibernate.ByteCode.Castle");
			_factory = null;
		}

		/// <summary>
		/// Thread safe NHibernate Session Factory
		/// </summary>
		public static ISessionFactory Factory
		{
			get
			{
				if (_factory == null)
				{
					lock (_locker)
					{
						if (_factory == null)
						{
							_factory = Current.BuildSessionFactory();
						}
					}
				}
				return _factory;
			}
		}

		#endregion

		private static string GetConnectionString()
		{
			return ConfigurationManager.ConnectionStrings["Main"].ConnectionString; 
		}
	}
}
