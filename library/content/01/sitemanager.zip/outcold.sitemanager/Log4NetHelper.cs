﻿using System;
using System.IO;
using log4net;
using log4net.Config;

namespace outcold.sitemanager
{
    public class Log4NetHelper
    {
        public static ILog Log { get; private set;}

        private const string _key = "Log4NetConfiguration";

        public static void InitLogger()
        {
            string pathFileConfiguration = System.Configuration.ConfigurationManager.AppSettings.Get(_key);
            XmlConfigurator.ConfigureAndWatch(new FileInfo(AppDomain.CurrentDomain.BaseDirectory + pathFileConfiguration));
            Log = LogManager.GetLogger("Application");
        }
    }
}
