﻿using System;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;

namespace WebApplicationZipSample
{
	public partial class ZipFile : Page
	{
		/// <summary>
		/// Реализация ресурса для зипования
		/// </summary>
		class MemoryStreamStaticDataSource : ICSharpCode.SharpZipLib.Zip.IStaticDataSource, IDisposable
		{
			private MemoryStream MemoryStream { get; set; }

			/// <summary>
			/// Создаем ресурс с MemoryStream
			/// </summary>
			/// <param name="bytes"></param>
			public MemoryStreamStaticDataSource(byte[] bytes)
			{
				MemoryStream = new MemoryStream(bytes) { Position = 0 };
			}

			#region IStaticDataSource Members

			public Stream GetSource()
			{
				return MemoryStream;
			}

			#endregion

			#region IDisposable Members

			public void Dispose()
			{
				if (MemoryStream != null)
					MemoryStream.Dispose();
			}

			#endregion
		}

		/// <summary>
		/// Переобпеределяем загрузку страницы, и возвращаем zip файл
		/// </summary>
		/// <param name="e"></param>
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			Response.Clear();
			//Указывает MIME тип
			Response.ContentType = "application/zip";
			//Указываем, что приаттачен файл с именем file.zip
			Response.AddHeader("Content-Disposition", string.Format("attachment; filename=\"{0}\"", HttpUtility.UrlEncodeUnicode("file.zip")));

			//Получаем данные(файл архива) и записываем в Response
			byte[] bytes = GetZipData();
			Response.OutputStream.Write(bytes, 0, bytes.Length);
		}

		private static byte[] GetZipData()
		{
			//Создаем архив в памяти
			using (MemoryStream ms = new MemoryStream())
			{
				using (ICSharpCode.SharpZipLib.Zip.ZipFile file = new ICSharpCode.SharpZipLib.Zip.ZipFile(ms))
				{
					file.BeginUpdate();

					//Добавляем в архив первый файл
					file.Add(new MemoryStreamStaticDataSource(GetFirstFileData()), "file1.txt");
					//Добавляем в архив второй файл
					file.Add(new MemoryStreamStaticDataSource(GetSecondFileData()), "file2.txt");

					file.CommitUpdate();
				}

				return ms.ToArray();
			}
		}

		/// <summary>
		/// Пример, получаем данные первого сгенерированного файла
		/// </summary>
		/// <returns></returns>
		private static byte[] GetFirstFileData()
		{
			return GetFileData(@"Первый файл.");
		}

		/// <summary>
		/// Пример, получаем данные второго сгенерированного файла
		/// </summary>
		/// <returns></returns>
		private static byte[] GetSecondFileData()
		{
			return GetFileData(@"Второй файл.");
		}

		private static byte[] GetFileData(string textdata)
		{
			return Encoding.UTF8.GetBytes(textdata);
		}
	}
}
