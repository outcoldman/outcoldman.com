﻿using System;
using System.Runtime.InteropServices.Automation;
using System.Windows;
using System.Windows.Controls;
using ExportToExcelTools;

namespace ExportToExcelSample
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      if (!AutomationFactory.IsAvailable)
        MessageBox.Show("Install app on your box first.");
      else
        grid.ExportToExcel();
    }
  }
}
