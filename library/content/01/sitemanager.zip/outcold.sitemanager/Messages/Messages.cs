﻿using System.Xml.Serialization;

namespace outcold.sitemanager.Messages
{
	[XmlRoot(Namespace = "outcold.sitemessages")]
	public sealed class Messages
	{
		[XmlElement("Message")]
		public Message[] List { get; set; }
	}
}