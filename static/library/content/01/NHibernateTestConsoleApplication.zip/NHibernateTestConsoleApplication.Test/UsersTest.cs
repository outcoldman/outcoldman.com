﻿using System.Collections.Generic;
using MbUnit.Framework;
using NHibernate.Criterion;
using NHibernateTestConsoleApplication.Core.DAL;
using NHibernateTestConsoleApplication.Core.Domain;

namespace NHibernateTestConsoleApplication.Test
{
	[TestFixture]
	public class UsersTest
	{
		[TestFixtureSetUp]
		public void TestFixtureSetUp()
		{
			Configuration.ReConfigurate();
			Configuration.Current.AddAssembly(typeof (User).Assembly);
		}

		[Test]
		public void UsersShouldBeSave()
		{
			using (DataContext dataContext = new DataContext(true))
			{
				User user = new User { Name = "User1_Name", Surname = "User1_Surname" };
				dataContext.CurrentSession.Save(user);
			}

			IList<User> users;
			using (DataContext dataContext = new DataContext())
			{
				users = dataContext.CurrentSession.CreateCriteria<User>()
					.Add(Restrictions.Eq("Name", "User1_Name"))
					.List<User>();
			}

			Assert.AreEqual(users.Count, 1);
			Assert.AreEqual(users[0].Surname, "User1_Surname");

			using (DataContext dataContext = new DataContext(true))
			{
			    dataContext.CurrentSession.Delete(users[0]);
			}
		}
	}
}
