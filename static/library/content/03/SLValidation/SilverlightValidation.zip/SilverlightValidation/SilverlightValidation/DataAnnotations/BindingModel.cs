﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows;

namespace SilverlightValidation.DataAnnotations
{
	public class BindingModel : INotifyPropertyChanged
	{
		private string _newPassword;
		private string _newPasswordConfirmation;

		#region INotifyPropertyChanged

		public event PropertyChangedEventHandler PropertyChanged = delegate { };

		private void OnPropertyChanged(string propertyName)
		{
			PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
		}

		#endregion

		public DelegateCommand ChangePasswordCommand { get; private set; }

		public BindingModel()
		{
			ChangePasswordCommand = new DelegateCommand(ChangePassword, CanChangePassword);
		}

		private bool CanChangePassword(object arg)
		{
			return IsValidObject();
		}

		private void ChangePassword(object obj)
		{
			if (ChangePasswordCommand.CanExecute(obj))
			{
				MessageBox.Show("Bingo!");
			}
		}

		private bool IsValidObject()
		{
			ICollection<ValidationResult> results = new Collection<ValidationResult>();
			return Validator.TryValidateObject(this, new ValidationContext(this, null, null), results, true) && results.Count == 0;
		}

		private void ValidateProperty(string propertyName, object value)
		{
			Validator.ValidateProperty(value, new ValidationContext(this, null, null) { MemberName = propertyName });
		}

		[Required]
		[StringLength(20)]
		[Display(Name = "New password")]
		public string NewPassword
		{
			get { return _newPassword; }
			set
			{
				_newPassword = value;
				OnPropertyChanged("NewPassword");
				ChangePasswordCommand.RaiseCanExecuteChanged();
				ValidateProperty("NewPassword", value);
			}
		}

		[CustomValidation(typeof(BindingModel), "CheckPasswordConfirmation")]
		[Display(Name = "New password confirmation")]
		public string NewPasswordConfirmation
		{
			get { return _newPasswordConfirmation; }
			set
			{
				_newPasswordConfirmation = value;
				OnPropertyChanged("NewPasswordConfirmation");
				ChangePasswordCommand.RaiseCanExecuteChanged();
				ValidateProperty("NewPasswordConfirmation", value);
			}
		}

		// Validation with simple exception throw
		//[Display(Name = "New password confirmation")]
		//public string NewPasswordConfirmation
		//{
		//    get { return _newPasswordConfirmation; }
		//    set
		//    {
		//        _newPasswordConfirmation = value;
		//        OnPropertyChanged("NewPasswordConfirmation");
		//        ChangePasswordCommand.RaiseCanExecuteChanged();
		//        if (string.CompareOrdinal(_newPassword, value) != 0)
		//            throw new Exception("Password confirmation not equal to password.");
		//    }
		//}

		public static ValidationResult CheckPasswordConfirmation(string value, ValidationContext context)
		{
			var bindingModel = context.ObjectInstance as BindingModel;
			if (bindingModel == null)
				throw new NotSupportedException("ObjectInstance must be BindingModel");

			if (string.CompareOrdinal(bindingModel._newPassword, value) != 0)
				return new ValidationResult("Password confirmation not equal to password.");

			return ValidationResult.Success;
		}
	}
}
