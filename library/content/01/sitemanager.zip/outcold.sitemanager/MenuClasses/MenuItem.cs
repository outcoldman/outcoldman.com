﻿using System.Xml.Serialization;

namespace outcold.sitemanager.MenuClasses
{
    public class MenuItem
    {
        [XmlAttribute]
        public string Title { get; set; }

        [XmlAttribute]
        public string SiteID { get; set; }

        [XmlAttribute]
        public string Url { get; set; }

        [XmlElement("MenuItem")]
        public MenuItem[] Items { get; set; }
    }
}