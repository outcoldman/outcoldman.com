﻿using System;

namespace LogSystem.Sample.Server
{
    class Program
    {
        private static ILogger Logger = LoggerFactory.GetLogger();

        static void Main()
        {
            while(true)
            {
                Console.WriteLine("Click Escape to exit or any key to input log message");
                ConsoleKeyInfo keyInfo = Console.ReadKey(true);
                if (keyInfo.Key == ConsoleKey.Escape)
                    break;

                string line = Console.ReadLine();
                Logger.Log(line);
            }
        }
    }
}
