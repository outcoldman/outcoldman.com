﻿using System.Xml.Serialization;

namespace outcold.sitemanager.ConfigurationClasses
{
    public class ItemContextParameter
    {
        [XmlAttribute]
        public string Name { get; set; }

        [XmlAttribute]
        public ParameterDataType DataType { get; set; }
    }
}