﻿namespace LogSystem
{
    internal class Logger : ILogger
    {
        private readonly IOutput _output;

        public Logger(IOutput output)
        {
            _output = output;
        }

        public void Log(string msg)
        {
            _output.PutMessage(msg);
        }
    }
}
