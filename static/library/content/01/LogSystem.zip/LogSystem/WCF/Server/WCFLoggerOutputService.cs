﻿using System;
using System.Security.Cryptography;
using System.ServiceModel;
using System.Text;
using LogSystem.Security;

namespace LogSystem.WCF.Server
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession
        , ConcurrencyMode = ConcurrencyMode.Multiple)]
    internal class WCFLoggerOutputService : IWCFLoggerOutput
    {
        private IWCFLoggerOutputCallback Listener { get; set; }
        private RSAParameters? RSAParameters { get; set;}

        public bool IsSecure
        {
            get { return RSAParameters.HasValue; }
        }

        public void RegisterListener()
        {
            Listener = OperationContext.Current.GetCallbackChannel<IWCFLoggerOutputCallback>();
            WCFOutput.RegisterOnLog(Log);
        }

        public void RegisterSecureListener(RSAParameters parameters)
        {
            RSAParameters = parameters;
            RegisterListener();
        }

        private bool Log(string message)
        {
            try
            {
                byte[] bData = Encoding.Unicode.GetBytes(message);
                if (IsSecure)
                {
                    bData = RSAHelper.Encrypt(bData, RSAParameters.Value);
                }
                Listener.Log(bData);

                return true;
            }
            // TODO: log error with log4net
            catch(Exception)
            {
                return false;
            }
        }

        public void CloseChannel()
        {
            WCFOutput.UnRegisterOnLog(Log);
        }
    }
}