﻿using System.Configuration;
using System.Data.SqlClient;

namespace SampleWebApplication.Domain
{
	public static class DataAccessor
	{
		public static SqlConnection SqlConnection
		{
			get { return new SqlConnection(ConfigurationManager.ConnectionStrings["Main"].ConnectionString); }
		}
	}
}