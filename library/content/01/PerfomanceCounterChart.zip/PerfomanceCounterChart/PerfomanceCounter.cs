﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using ThreadState=System.Threading.ThreadState;

namespace PerfomanceCounterChart
{
	public partial class PerfomanceCounter : Form
	{
		public PerfomanceCounter()
		{
			InitializeComponent();
			InitCounters();
		}

		#region Counters

		private PerformanceCounter pcCpu;
		private PerformanceCounter pcRam;
		private PerformanceCounter pcPage;

        /// <summary>
        /// Инициализация счетчиков
        /// </summary>
		private void InitCounters()
		{
			pcCpu = new PerformanceCounter("Processor", "% Processor Time", "_Total", Environment.MachineName);
			pcRam = new PerformanceCounter("Memory", "% Committed Bytes In Use", String.Empty, Environment.MachineName);
			pcPage = new PerformanceCounter("Paging File", "% Usage", "_Total", Environment.MachineName);
		}

        /// <summary>
        /// Освобождаем ресурсы - PerformanceCounters
        /// </summary>
		private void DisposeCounters()
		{
			try
			{
				if (pcCpu != null)
					pcCpu.Dispose(); 
				if (pcRam != null)
					pcRam.Dispose(); 
				if (pcPage != null)
					pcPage.Dispose(); 
			}
			finally
			{
				PerformanceCounter.CloseSharedResources();
			}
		}

		#endregion

		#region Thread Sample

		private Thread addDataRunner;
		public delegate void AddDataDelegate();
		public AddDataDelegate addDataDel;

        /// <summary>
        /// Инициализируем поток, который будет добавлять нам данные в график
        /// </summary>
        /// <param name="e"></param>
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			Application.DoEvents();

			// create the Adding Data Thread but do not start until start button clicked
			ThreadStart addDataThreadStart = new ThreadStart(AddDataThreadLoop);
			addDataRunner = new Thread(addDataThreadStart);

			// create a delegate for adding data
			addDataDel += new AddDataDelegate(AddData);

			// start worker threads.
			if (addDataRunner.IsAlive == true)
			{
				addDataRunner.Resume();
			}
			else
			{
				addDataRunner.Start();
			}
		}

        /// <summary>
        /// Вызываем работу подсчета каждые 0.1 секунды
        /// </summary>
		private void AddDataThreadLoop()
		{
			while (true)
			{
				if (!chartPerfomance.IsHandleCreated)
					return;

				chartPerfomance.Invoke(addDataDel);

				Thread.Sleep(100);
			}
		}

        /// <summary>
        /// Заканчиваем работу потока
        /// </summary>
        private void DisposeThread()
        {
            if ((addDataRunner.ThreadState & ThreadState.Suspended) == ThreadState.Suspended)
            {
                addDataRunner.Resume();
            }
            addDataRunner.Abort();
        }

		#endregion

		#region Add Data 

        /// <summary>
        /// Метод добавляет данные в три графика на данный период времени
        /// </summary>
		public void AddData()
		{
			DateTime timeStamp = DateTime.Now;

			AddNewPoint(timeStamp, chartPerfomance.Series[0], pcCpu.NextValue());
			AddNewPoint(timeStamp, chartPerfomance.Series[1], pcRam.NextValue());
			AddNewPoint(timeStamp, chartPerfomance.Series[2], pcPage.NextValue());
		}

        /// <summary>
        /// Добавление точки (timeStamp, nexVal) в график ptSeries
        /// </summary>
        /// <param name="timeStamp"></param>
        /// <param name="ptSeries"></param>
        /// <param name="nexVal"></param>
		public void AddNewPoint( DateTime timeStamp, Series ptSeries, float nexVal )
		{
			ptSeries.Points.AddXY(timeStamp.ToOADate(), nexVal);

			double removeBefore = timeStamp.AddSeconds( (double)(9) * ( -1 )).ToOADate();
			
			while ( ptSeries.Points[0].XValue < removeBefore )
			{
				ptSeries.Points.RemoveAt(0);
			}

			chartPerfomance.ChartAreas[0].AxisX.Minimum = ptSeries.Points[0].XValue;
			chartPerfomance.ChartAreas[0].AxisX.Maximum = DateTime.FromOADate(ptSeries.Points[0].XValue).AddSeconds(10).ToOADate();

			chartPerfomance.Invalidate();
		}

		#endregion
        
		#region Mouse Events

        /// <summary>
        /// Движение мыши 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void chartPerfomance_MouseMove(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
			    int x = savedRotation - (savedLocation.X - e.X);
                int y = savedInclination - (savedLocation.Y - e.Y);
                chartPerfomance.ChartAreas[0].Area3DStyle.Rotation = Math.Max(Math.Min(x, 180), -180); //x % 360 - 360 * ((x / 180) % 2);
                chartPerfomance.ChartAreas[0].Area3DStyle.Inclination = Math.Max(Math.Min(y, 90), -90);
			}
		}

        /// <summary>
        /// Нажатие на кнопку мыши
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void chartPerfomance_MouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				Cursor = Cursors.NoMove2D;
			    savedLocation = e.Location;
				savedRotation = chartPerfomance.ChartAreas[0].Area3DStyle.Rotation;
				savedInclination = chartPerfomance.ChartAreas[0].Area3DStyle.Inclination;
			}
		}

        /// <summary>
        /// Кнопку отпустили
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void chartPerfomance_MouseUp(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				Cursor = Cursors.Default;
			}
		}

        private Point savedLocation;
		private int savedRotation;
		private int savedInclination;

		#endregion
	}
}
