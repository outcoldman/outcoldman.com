﻿using System;
using System.Security.Cryptography;
using System.ServiceModel;

namespace LogSystem.WCF.Client
{
    internal class WCFClient : DuplexClientBase<IWCFLoggerOutput>
    {
        public IWCFLoggerOutputCallback Callback { get; set; }

        public WCFClient(WCFListener listener, string endPoint)
            : base(new InstanceContext(listener), ServiceHelper.GetDefaultBinding(), new EndpointAddress(endPoint))
        {
        }

        public void RegisterListener()
        {
            Channel.RegisterListener();
        }

        public void RegisterListener(RSAParameters parameters)
        {
            Channel.RegisterSecureListener(parameters);
        }

        public void CloseChannel()
        {
            try
            {
                Channel.CloseChannel();
            }
            // TODO: Use log4net to log this exceptions
            catch (Exception)
            {
                Abort();
            }
        }
    }
}