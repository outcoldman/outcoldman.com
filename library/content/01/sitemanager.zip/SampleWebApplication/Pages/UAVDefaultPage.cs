﻿using System.Web.UI;

namespace SampleWebApplication.Pages
{
    public class UAVDefaultPage : Page
    {
        public MasterPages.Default MasterPage
        {
            get { return Master as MasterPages.Default; }
        }
    }
}