﻿using System;
using System.Reflection;
using log4net;
using NHibernate;

namespace NHibernateTestConsoleApplication.Core.DAL
{
	/// <summary>
	/// Context for work with NHibernate Sessions
	/// </summary>
	public class DataContext : IDisposable
	{
		private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

		/// <summary>
		/// Create new context and open session
		/// </summary>
		public DataContext()
		{
			OpenSession();
		}

		/// <summary>
		/// Create new context and open session
		/// </summary>
		/// <param name="fBeginTransaction">need to begin transaction</param>
		public DataContext(bool fBeginTransaction)
		{
			OpenSession();
			if (fBeginTransaction)
				BeginTransaction();
		}

		private ISession _session;
		private ITransaction _transaction;

		/// <summary>
		/// Return current session
		/// </summary>
		public ISession CurrentSession
		{
			get
			{
				try
				{
					OpenSession();
				}
				catch (HibernateException e)
				{
					Log.Error("Cannot open session", e);
					throw;
				}

				return _session;
			}
		}

		/// <summary>
		/// Open session if not opened before
		/// </summary>
		public void OpenSession()
		{
			if (_session == null)
			{
				_session = Configuration.Factory.OpenSession();
				_session.FlushMode = FlushMode.Commit;
			}
		}

		/// <summary>
		/// Close session if it opened
		/// </summary>
		public void CloseSession()
		{
			try
			{
				if (_session != null && _session.IsOpen)
				{
					_session.Close();
				}
				_session = null;
			}
			catch (HibernateException e)
			{
				Log.Error("Cannot close session", e);
				throw;
			}
		}

		/// <summary>
		/// Begin transaction if it not started before
		/// </summary>
		public void BeginTransaction()
		{
			try
			{
				if (_transaction == null)
				{
					_transaction = CurrentSession.BeginTransaction();
				}
			}
			catch (HibernateException e)
			{
				Log.Error("Cannot begin transaction", e);
				throw;
			}
		}

		/// <summary>
		/// Commit current transaction if it opened
		/// </summary>
		public void CommitTransaction()
		{
			try
			{
				if (_transaction != null && !_transaction.WasCommitted &&
					!_transaction.WasRolledBack)
				{
					_transaction.Commit();
				}
				_transaction = null;
			}
			catch (HibernateException e)
			{
				Log.Error("Cannot commit transaction", e);
				throw;
			}
		}

		/// <summary>
		/// Rollback current transaction
		/// </summary>
		public void RollbackTransaction()
		{
			try
			{
				if (_transaction != null && !_transaction.WasCommitted &&
					!_transaction.WasRolledBack)
					_transaction.Rollback();

				_transaction = null;
			}
			catch (HibernateException e)
			{
				Log.Error("Cannot rollback transaction", e);
				throw;
			}
			finally
			{
				CloseSession();
			}
		}

		/// <summary>
		/// Commit transaction if requied and close session
		/// </summary>
		public void Dispose()
		{
			CommitTransaction();
			CloseSession();
		}
	}
}