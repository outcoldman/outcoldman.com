﻿using System.Security.Cryptography;
using System.ServiceModel;

namespace LogSystem.WCF
{
    [ServiceContract(SessionMode = SessionMode.Required, 
        CallbackContract = typeof(IWCFLoggerOutputCallback))]
    internal interface IWCFLoggerOutput
    {
        [OperationContract(IsOneWay = true)]
        void RegisterListener();

        /// <summary>
        ///  log with encrypt
        /// </summary>
        /// <param name="parameters">Send public key to encrypt</param>
        [OperationContract(IsOneWay = true)]
        void RegisterSecureListener(RSAParameters parameters);

        [OperationContract(IsOneWay = true, IsTerminating = true)]
        void CloseChannel();
    }
}