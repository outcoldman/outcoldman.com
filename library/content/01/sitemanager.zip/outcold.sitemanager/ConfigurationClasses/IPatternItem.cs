﻿namespace outcold.sitemanager.ConfigurationClasses
{
    internal interface IPatternItem : IConfigurationItem
    {
        string Pattern { get; set; }
		ItemContextParameter ContextParameter { get; set; }
		ItemParameter[] Parameters { get; set; }
    }
}