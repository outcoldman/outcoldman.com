﻿using System;
using outcold.sitemanager.HTTP;
using SampleWebApplication.Domain;

namespace SampleWebApplication.Pages.Catalog
{
    public partial class ItemView : UAVDefaultPage
    {
		private int? _firmID;

		protected int? FirmID
		{
			get
			{
				if (!_firmID.HasValue)
				{
					_firmID = HttpContextHelper.GetInt32("firmID");
				}
				return _firmID;
			}
		}

		private int? _categoryID;

		protected int? CategoryID
		{
			get
			{
				if (!_categoryID.HasValue)
				{
					_categoryID = HttpContextHelper.GetInt32("categoryID");
				}
				return _categoryID;
			}
		}

		private int? _itemID;

		protected int? ItemID
		{
			get
			{
				if (!_itemID.HasValue)
				{
					_itemID = HttpContextHelper.GetInt32("id");
				}
				return _itemID;
			}
		}

		private Item _item;

		protected Item Item
		{
			get
			{
				if (_item == null && ItemID.HasValue)
				{
					_item = Item.Find(ItemID.Value);
				}
				return _item;
			}
		}

    	protected bool IsActive
    	{
			get { return Item != null && Item.IsActive; }
    	}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			MasterPage.Title = IsActive ? Item.Title : "Продукт не найден.";
		}
    }
}
