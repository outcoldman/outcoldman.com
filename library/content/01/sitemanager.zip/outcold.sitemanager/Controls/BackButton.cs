﻿using System;
using System.Web.UI.WebControls;
using outcold.sitemanager.Utils;

namespace outcold.sitemanager.Controls
{
	public class BackButton : Button
	{
		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);
			Click += BackButton_Click;
			if (string.IsNullOrEmpty(Text))
				Text = "Назад";
			if (!Page.IsPostBack && Page.Request.UrlReferrer != null)
				Page.Session[ClientID + "_BackUrl"] = Page.Request.UrlReferrer.AbsolutePath;
		}

		private void BackButton_Click(object sender, EventArgs e)
		{
			string refUrl = Parser.GetString(Page.Session[ClientID + "_BackUrl"]);
			if (!string.IsNullOrEmpty(refUrl))
				NavigationManager.GoToUrl(refUrl);
			NavigationManager.GoToBackUrl();
		}
	}
}