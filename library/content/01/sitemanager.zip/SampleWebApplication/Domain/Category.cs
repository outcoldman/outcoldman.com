﻿using System.Data;
using System.Data.SqlClient;
using Castle.ActiveRecord;
using outcold.sitemanager.DataAccess;

namespace SampleWebApplication.Domain
{
    /// <summary>
    /// Класс категорий
    /// </summary>
	[ActiveRecord]
	public class Category : HttpActiveRecordBase<Category>
    {
		[PrimaryKey("categoryID")]
        public int? ID { get; private set; }

		[Property]
        public string Name { get; set; }

		[BelongsTo("parentID")]
		public Category Parent { get; set; }

		/// <summary>
		/// Get Categories for DropDownList
		/// </summary>
		/// <returns>Table(categoryID,name)</returns>
		public static DataTable GetCategories()
        {
			DataTable dt = new DataTable();
            using (SqlConnection connection = DataAccessor.SqlConnection)
            {
                connection.Open();
				SqlDataAdapter a = new SqlDataAdapter(@"exec CategoriesDropDownList", connection);
				a.Fill(dt); 
                connection.Close();
            }
        	return dt;
        }
    }
}
