﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using LinqToTwitter;

namespace TwitterCloud.Model
{
    public class MainWindowModel : DependencyObject
    {
        #region Private Classes

        private class Result
        {
            public readonly IDictionary<string, int> Statistic = new Dictionary<string, int>();
            public readonly IDictionary<string, int> StatisticHash = new Dictionary<string, int>();
            public readonly IDictionary<string, int> StatisticUser = new Dictionary<string, int>();
        }

        #endregion

        public static readonly DependencyProperty ProgressProperty =
            DependencyProperty.Register("Progress", typeof (int), typeof (MainWindowModel), new UIPropertyMetadata(0));

        public static readonly DependencyProperty IsBusyProperty =
            DependencyProperty.Register("IsBusy", typeof (bool), typeof (MainWindowModel), new UIPropertyMetadata(false));

        private const string RuCultureName = "ru-RU";
        private const string RuParasitesWords = "-,и,а,о";
        private const string OtherParasitesWords = "was,be,been,-";
        private const int TweetsPerPage = 20;

        private readonly BackgroundWorker _worker = new BackgroundWorker
                                                        {
                                                            WorkerSupportsCancellation = true,
                                                            WorkerReportsProgress = true
                                                        };

        public MainWindowModel()
        {
            Statistic = new ObservableCollection<TopWord>();
            StatisticHash = new ObservableCollection<TopWord>();
            StatisticUser = new ObservableCollection<TopWord>();
            CultureInfo culture = Thread.CurrentThread.CurrentCulture;
            ParasitesWords = culture.Name == RuCultureName ? RuParasitesWords : OtherParasitesWords;

            _worker.DoWork += CreateStatistic;
            _worker.ProgressChanged += WorkerProgressChanged;
            _worker.RunWorkerCompleted += WorkerRunWorkerCompleted;
        }

        #region Properties

        public string ParasitesWords { get; set; }

        public string UserName { get; set; }

        public string Password { get; set; }

        public BackgroundWorker Worker
        {
            get { return _worker; }
        }

        public ObservableCollection<TopWord> Statistic { get; set; }

        public ObservableCollection<TopWord> StatisticHash { get; set; }

        public ObservableCollection<TopWord> StatisticUser { get; set; }

        public int Progress
        {
            get { return (int) GetValue(ProgressProperty); }
            set { SetValue(ProgressProperty, value); }
        }

        public bool IsBusy
        {
            get { return (bool) GetValue(IsBusyProperty); }
            set { SetValue(IsBusyProperty, value); }
        }

        #endregion

        public bool IsValid()
        {
            return !string.IsNullOrEmpty(UserName) && !string.IsNullOrEmpty(Password);
        }

        public void CreateStatistic(object sender, DoWorkEventArgs e)
        {
            UsernamePasswordAuthorization auth = new UsernamePasswordAuthorization
                                                     {
                                                         UserName = UserName,
                                                         Password = Password
                                                     };
            // For logging
            using (StreamWriter writer = new StreamWriter(string.Format("{0}.log", DateTime.Now.ToString("yyyy_dd_MM_HH_ss"))))
            // Основной провайдер для работы с twitter 
            using (TwitterContext twitterCtx = new TwitterContext(auth))
            {
                // Осуществляем авторизацию 
                auth.SignOn();
                auth.SignOff();
                auth.SignOn();
                Account user = twitterCtx.Account.Where(x => x.User.ID == UserName).FirstOrDefault();
                ulong cStatuses = user.User.StatusesCount;

                Result result = new Result();

                int sumCount = 0;
                int pageCount = (int)cStatuses / TweetsPerPage + ((cStatuses % TweetsPerPage) == 0 ? 0 : 1);
                for (int pIndex = 1; pIndex <= pageCount; pIndex++)
                {
                    IList<Status> publicTweets = LoadTweets(twitterCtx, pIndex);

                    IList<string> parasites =
                        new List<string>(ParasitesWords.Split(new[] {' ', ','},
                                                              StringSplitOptions.RemoveEmptyEntries));

                    sumCount += publicTweets.Count;

                    // For report progress
                    int iTweet = 0;

                    foreach (Status tweet in publicTweets)
                    {
                        // Log tweet
                        writer.WriteLine(tweet.Text);

                        string[] words = tweet.Text.Split(new[] {' ', '.', ',', '?', '!'},
                                                         StringSplitOptions.RemoveEmptyEntries);

                        foreach (string word in words)
                        {
                            // Убираем слова паразиты и ссылки
                            if (parasites.Contains(word)
                                || word.StartsWith("http://")) continue;

                            // Статистика по адресованным сообщениям
                            if (word.StartsWith("@"))
                                AddWord(result.StatisticUser, word);

                                // Статистика по #
                            else if (word.StartsWith("#"))
                                AddWord(result.StatisticHash, word);

                                // Статистика по словам
                            else AddWord(result.Statistic, word);

                            if (_worker.CancellationPending)
                                return;
                        }

                        // Wait. TwitterAPI блокирует
                        Thread.Sleep(200);

                        _worker.ReportProgress((int) (((pIndex*TweetsPerPage + (++iTweet))/(double) cStatuses)*100));
                    }
                }

                auth.SignOff();

                Debug.Assert(sumCount == (int) cStatuses);

                e.Result = result;
            }
        }

        private void WorkerProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            Progress = e.ProgressPercentage;
        }

        private void WorkerRunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            IsBusy = false;
            try
            {
                Result result = e.Result as Result;
                if (result != null)
                {
                    UpdateStatistic(Statistic, result.Statistic);
                    UpdateStatistic(StatisticHash, result.StatisticHash);
                    UpdateStatistic(StatisticUser, result.StatisticUser);
                }
            }
            catch (Exception)
            {
                MessageBox.Show(Application.Current.MainWindow,
                                "This may be caused by the server being busy.\r\nAlso check username/password.",
                                "Cannot process request.", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        private IList<Status> LoadTweets(TwitterContext twitterCtx, int page)
        {
            int tryCount = 0;

            while (true)
            {
                try
                {
                    return (from tweet in twitterCtx.Status
                            where tweet.Type == StatusType.User
                                  && tweet.Page == page
                                  && tweet.ID == UserName
                            //&& !tweet.Text.StartsWith("RT ")
                            //&& tweet.Count == TweetsPerPage
                            select tweet).ToList();
                }
                catch (Exception)
                {
                    if (tryCount == 3)
                        throw;
                    
                    Thread.Sleep(500);

                    tryCount++;
                }
            }
        }

        private static void UpdateStatistic(ICollection<TopWord> stat, IEnumerable<KeyValuePair<string, int>> dStatistic)
        {
            stat.Clear();

            (from x in dStatistic
             orderby x.Value descending
             select x).Select(x => new TopWord {Count = x.Value, Word = x.Key})
                .ToList().ForEach(stat.Add);
        }

        private static void AddWord(IDictionary<string, int> dStatistic, string word)
        {
            if (dStatistic.ContainsKey(word))
                dStatistic[word]++;
            else
                dStatistic.Add(word, 1);
        }
    }
}