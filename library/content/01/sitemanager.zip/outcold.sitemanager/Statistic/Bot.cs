﻿using System.Xml.Serialization;

namespace outcold.sitemanager.Statistic
{
	public sealed class Bots
	{
		[XmlElement("Bot")]
		public Bot[] List { get; set; }
	}

	public sealed class Bot
	{
		[XmlAttribute]
		public string Mask { get; set; }

		[XmlAttribute]
		public int ID { get; set; }
	}
}