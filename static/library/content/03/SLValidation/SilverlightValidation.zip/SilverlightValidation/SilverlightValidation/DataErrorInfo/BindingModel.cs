﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows;

namespace SilverlightValidation.DataErrorInfo
{
	public class BindingModel : INotifyPropertyChanged, IDataErrorInfo
	{
		private string _newPassword;
		private string _newPasswordConfirmation;
		private readonly ValidationHandler _validationHandler = new ValidationHandler();

		#region INotifyPropertyChanged

		public event PropertyChangedEventHandler PropertyChanged = delegate { };

		private void OnPropertyChanged(string propertyName)
		{
			PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
		}

		#endregion

		public BindingModel()
		{
			ChangePasswordCommand = new DelegateCommand(ChangePassword, CanChangePassword);
		}

		public DelegateCommand ChangePasswordCommand { get; private set; }

		private bool CanChangePassword(object arg)
		{
			return !string.IsNullOrEmpty(_newPassword) 
				&& string.CompareOrdinal(_newPassword, _newPasswordConfirmation) == 0;
		}

		private void ChangePassword(object obj)
		{
			if (ChangePasswordCommand.CanExecute(obj))
			{
				MessageBox.Show("Bingo!");
			}
		}

		#region IDataErrorInfo

		public string this[string columnName]
		{
			get
			{
				if (_validationHandler.BrokenRuleExists(columnName))
				{
					return _validationHandler[columnName];
				}
				return null;
			}
		}

		public string Error
		{
			get { throw new NotImplementedException(); ; }
		}

		#endregion

		[Display(Name = "New password")]
		public string NewPassword
		{
			get { return _newPassword; }
			set
			{
				_newPassword = value;
				OnPropertyChanged("NewPassword");

				if (_validationHandler.ValidateRule("NewPassword", "New password required", 
											() => !string.IsNullOrEmpty(value)))
				{
					_validationHandler.ValidateRule("NewPassword", "Max length of password is 80 symbols.", 
											() => value.Length < 80);
				}

				ChangePasswordCommand.RaiseCanExecuteChanged();
			}
		}

		[Display(Name = "New password confirmation")]
		public string NewPasswordConfirmation
		{
			get { return _newPasswordConfirmation; }
			set
			{
				_newPasswordConfirmation = value;
				OnPropertyChanged("NewPasswordConfirmation");

				_validationHandler.ValidateRule("NewPasswordConfirmation", "Password confirmation not equal to password.",
				                                () => string.CompareOrdinal(_newPassword, value) == 0);

				ChangePasswordCommand.RaiseCanExecuteChanged();
			}
		}
	}
}