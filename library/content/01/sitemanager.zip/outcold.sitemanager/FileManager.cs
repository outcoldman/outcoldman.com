﻿using System;
using System.Drawing;
using System.IO;
using outcold.sitemanager.Utils;

namespace outcold.sitemanager
{
	public class FileManager
	{
		public static string GetPath(string path)
		{
			return Path.GetFullPath(string.Format(@"{0}{1}{2}",
												  AppDomain.CurrentDomain.SetupInformation.ApplicationBase, Path.DirectorySeparatorChar, path));
		}

		public static string SaveGuidFile(string folder, string extension, byte[] fileBytes)
		{
			string guidFileName = Guid.NewGuid().ToString();
			string fileName = string.Format("{0}{1}", guidFileName, extension);
			SaveFile(folder, fileName, fileBytes);
			return string.Format("{0}{1}{2}", folder, Path.DirectorySeparatorChar, fileName);
		}

		public static void SaveFile(string folder, string fileName, byte[] fileBytes)
		{
			string filePath = GetPath(string.Format("{0}{1}{2}", folder, Path.DirectorySeparatorChar, fileName));
			using (FileStream file = new FileStream(filePath, FileMode.CreateNew))
			{
				file.Write(fileBytes, 0, fileBytes.Length);
			}
		}

		public static void DeleteFile(string fileName)
		{
			try
			{
				string fullPath = GetPath(fileName);
				if (File.Exists(fullPath))
					File.Delete(fullPath);
			}
			catch(Exception e)
			{
				Log4NetHelper.Log.Error(e);
			}
		}

		public static Size GetImageSize(string imgPath)
		{
			string image = GetPath(imgPath);
			return Image.FromFile(image).Size;
		}

		public static Size GetImageSize(int width, int height, int? wMax, int? hMax)
		{
			float w = 1;
			float h = 1;
			if (wMax.HasValue && wMax.Value > 0)
				w = ((float)wMax.Value) / ((float)width);
			if (hMax.HasValue && hMax.Value > 0)
				h = ((float)hMax.Value) / ((float)height);
			float scale = Math.Min(w, h);
			return new Size(Math.Min(width, (int)(((float)width) * scale)), Math.Min(height, (int)(((float)height) * scale)));
		}

		public static string GetImageSizes(object imgW, object imgH, int? wMax, int? hMax)
		{
			int? w = Parser.GetInt(imgW);
			int? h = Parser.GetInt(imgH);
			if (h.HasValue && w.HasValue)
			{
				Size s = GetImageSize(w.Value, h.Value, wMax, hMax);
				return string.Format("width='{0}px' height='{1}px'", s.Width, s.Height);
			}
			return string.Empty;
		}
	}
}