﻿using System;
using System.Threading;
using LogSystem.WCF.Client;
using MbUnit.Framework;

namespace LogSystem.Test
{
    // ReSharper disable InconsistentNaming

    [TestFixture]
    public class LoggerSpec
    {
        static ILogger _logger;

        [TestFixtureSetUp]
        public void SetUpTests()
        {
            _logger = LoggerFactory.GetLogger();
        }

        /// <summary>
        /// Just one logger instance
        /// </summary>
        [Test]
        public void LoggerFactory_should_return_one_instance_of_logger()
        {
            ILogger logger = LoggerFactory.GetLogger();
            Assert.AreEqual(logger, _logger);
        }

        /// <summary>
        /// Test connection
        /// </summary>
        [Test]
        public void Logger_should_log()
        {
            _logger.Log("Message 0");

            using(WCFListener listener = new WCFListener("net.tcp://localhost:2222/Logger/", false))
            {
                listener.Log += new System.Action<string>(listener_Log);
                Thread.Sleep(1000);
                _logger.Log("Message 1");
                _logger.Log("Message 2");
                _logger.Log("Message 2.2");
            }

            _logger.Log("Message 3");
        }

        /// <summary>
        /// Test secure connection
        /// </summary>
        [Test]
        public void Logger_should_log_with_secure()
        {
            using (WCFListener listener = new WCFListener("net.tcp://localhost:2222/Logger/", true))
            {
                listener.Log += new System.Action<string>(listener_Log);
                Thread.Sleep(1000);
                _logger.Log("Message 1");
                _logger.Log("Message 2");
                _logger.Log("Message 2.2");
                Thread.Sleep(1000);
            }

            _logger.Log("Message 3");
        }

        void listener_Log(string obj)
        {
            Console.WriteLine(obj);
        }

        /// <summary>
        /// This test show that listener can work with many clients (one secure, other not secure)
        /// </summary>
        [Test]
        public void many_listeners_with_secure()
        {
            WCFListener[] listeners = new WCFListener[10];
            for (int i = 0; i < listeners.Length; i++)
            {
                listeners[i] = new WCFListener("net.tcp://localhost:2222/Logger/", i%2 == 1);
                listeners[i].Log += big_test_listener_Log;
            }

            counter = 0;

            _logger.Log("Big test");

            Thread.Sleep(5000);

            Assert.AreEqual(counter, listeners.Length);

            for (int i = 0; i < listeners.Length; i++)
            {
                listeners[i].Dispose();
            }
        }

        public static int counter = 0;

        private object _lock = new object();

        void big_test_listener_Log(string obj)
        {
            lock (_lock)
            {
                counter++;
                Console.WriteLine(obj);
            }
        }
    }

    // ReSharper restore InconsistentNaming
}
