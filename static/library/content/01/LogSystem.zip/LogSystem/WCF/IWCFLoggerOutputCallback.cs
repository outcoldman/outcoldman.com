﻿using System.ServiceModel;

namespace LogSystem.WCF
{
    /// <summary>
    /// Now support just unicode messages
    /// </summary>
    internal interface IWCFLoggerOutputCallback
    {
        [OperationContract(IsOneWay = true)]
        void Log(byte[] message);
    }
}