﻿using System.Data;
using System.Data.SqlClient;
using Castle.ActiveRecord;
using outcold.sitemanager.DataAccess;

namespace SampleWebApplication.Domain
{
    /// <summary>
    /// Класс фирм
    /// </summary>
	[ActiveRecord]
	public class Firm : HttpActiveRecordBase<Firm>
	{
		[PrimaryKey("firmID")]
        public int? ID { get; set; }

		[Property]
        public string Name { get; set; }

		[Property]
		public string Url { get; set; }

		[Property]
		public bool IsActive { get; set; }

		[Property]
		public string ImagePath { get; set; }

		/// <summary>
		/// Get Firms for DropDownList
		/// </summary>
		/// <returns>Table(firmID,name)</returns>
		public static DataTable GetFirms()
		{
			DataTable dt = new DataTable();
			using (SqlConnection connection = DataAccessor.SqlConnection)
			{
				connection.Open();
				SqlDataAdapter a = new SqlDataAdapter(@"exec FirmsDropDownList", connection);
				a.Fill(dt);
				connection.Close();
			}
			return dt;
		}
	}
}