﻿using System.Web;
using outcold.sitemanager.Utils;

namespace outcold.sitemanager.HTTP
{
	public class HttpContextHelper
	{
		public static int? GetInt32(string key)
		{
			return Parser.GetInt(HttpContext.Current.Items[key]);
		}

		public static string GetString(string key)
		{
			return Parser.GetString(HttpContext.Current.Items[key]);
		}
	}
}