﻿using System.Collections.Generic;
using System.Web.UI;
using outcold.sitemanager.MenuClasses;

namespace outcold.sitemanager.Controls
{
    public class UlMenu : Control
    {
        public string MenuID { get; set; }

        protected override void Render(HtmlTextWriter writer)
        {
            base.Render(writer);

            MenuClasses.Menu m = MenuManager.Current.GetMenuById(MenuID);
            if (m != null)
            {
            	MenuItem[] menuItems = m.Items;
            	PlaceMenuItems(writer, menuItems);
            }
        }

    	private static void PlaceMenuItems(HtmlTextWriter writer, IEnumerable<MenuItem> menuItems)
    	{
			if (menuItems != null)
			{
				writer.RenderBeginTag(HtmlTextWriterTag.Ul);
				foreach (MenuItem menuItem in menuItems)
				{
					writer.RenderBeginTag(HtmlTextWriterTag.Li);
					writer.AddAttribute(HtmlTextWriterAttribute.Href
					                    , !string.IsNullOrEmpty(menuItem.SiteID)
					                    	? NavigationManager.Current.GetUrl(menuItem.SiteID)
					                    	: menuItem.Url, true);
					writer.RenderBeginTag(HtmlTextWriterTag.A);
					writer.Write(menuItem.Title);
					if (menuItem.Items != null && menuItem.Items.Length > 0)
						writer.Write("<!--[if IE 7]><!-->");
					writer.RenderEndTag();
					if (menuItem.Items != null && menuItem.Items.Length > 0)
						writer.Write("<!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->");
					PlaceMenuItems(writer, menuItem.Items);
					if (menuItem.Items != null && menuItem.Items.Length > 0)
						writer.Write("<!--[if lte IE 6]></td></tr></table></a><![endif]-->");
					writer.RenderEndTag();
				}
				writer.RenderEndTag();
			}
    	}
    }
}