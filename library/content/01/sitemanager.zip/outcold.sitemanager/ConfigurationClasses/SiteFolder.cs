﻿using System.Xml.Serialization;

namespace outcold.sitemanager.ConfigurationClasses
{
    public sealed class SiteFolder : SiteItemsContainerBase, IPatternItem
    {
        [XmlAttribute]
        public string Pattern { get; set; }

        [XmlElement]
		public ItemContextParameter ContextParameter { get; set; }

		[XmlElement("Parameter")]
		public ItemParameter[] Parameters { get; set; }
    }
}
