﻿namespace outcold.sitemanager.ConfigurationClasses
{
    public enum ParameterDataType
    {
        integer = 1,
        literal = 2
    }
}