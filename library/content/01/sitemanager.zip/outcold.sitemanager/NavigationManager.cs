﻿using System;
using System.Web;
using outcold.sitemanager.ConfigurationClasses;
using outcold.sitemanager.HTTP;

namespace outcold.sitemanager
{
    public sealed class NavigationManager
    {
    	private const string keyOriginalURL = "OriginalUrl";
		private const string keyOriginalURLWithoutParams = "OriginalURLWithoutParams";

    	#region Singleton

        private static NavigationManager _current;
        private static object _locker = new object();

        public static NavigationManager Current
        {
            get
            {
				 if (_current == null)
				{
					lock (_locker)
					{
						if (_current == null)
						{
							_current = new NavigationManager(SiteItemsConfigurationManager.GetConfiguration());
						}
					}
				}
                return _current;
            }  
        }

        public static NavigationManager Init(NavigationManager current)
        {
            if (_current == null)
            {
                lock (_locker)
                {
                    if (_current == null)
                    {
                        _current = current;
                    }
                }
            }
            return _current;
        }

        private NavigationManager(Configuration configuration)
        {
            Configuration = configuration;
        }

        #endregion
        
        internal Configuration Configuration { get; private set; }

		public bool IsWorkURL
		{
			get
			{
				if (HttpContext.Current.Items.Contains(keyOriginalURL))
					return Configuration.IsExtension(HttpContext.Current.Items[keyOriginalURL].ToString());
				return false;
			}
		}

        public void OpenUrl(string url)
        {
            if (Configuration.IsExtension(url))
            {
				SiteItem item = GetItem(url);
                if (item != null)
                {
                    string path = HttpContext.Current.Request.Path;
                    // there us nothing to process
                    if (path.Length == 0 || string.IsNullOrEmpty(item.Location))
                        return;

                    HttpContext.Current.Items.Add(keyOriginalURL, HttpContext.Current.Request.RawUrl);
					HttpContext.Current.Items.Add(keyOriginalURLWithoutParams, url);
                    HttpContext.Current.RewritePath(item.Location);
                }
                else 
                {
					throw new HttpException(404, "Page not find");
                }
            }
        }

		public SiteItem CurrentItem
    	{
    		get
    		{
				if (HttpContext.Current.Items.Contains(keyOriginalURLWithoutParams))
					return GetItem(HttpContext.Current.Items[keyOriginalURLWithoutParams].ToString());
    			return null;
    		}
    	}

		private SiteItem GetItem(string url)
    	{
    		string appPath = HttpContext.Current.Request.ApplicationPath;
    		if (!string.IsNullOrEmpty(appPath))
				url = url.Substring(appPath.Length + (appPath.Length > 1 ? 1 : 0)
					, url.Length - appPath.Length - (appPath.Length > 1 ? 1 : 0)); // one for '/'

    		return Configuration.GetItem(url);
    	}

    	public string GetUrl(string itemid, params object[] parameters)
        {
            if (string.IsNullOrEmpty(itemid))
                throw new NullReferenceException("itemid");

            return GetSiteUrl(Configuration.GetUrlById(itemid, parameters));
        }

		public static string GetUrlWithHost(string url)
		{
			return string.Format("{0}://{1}{2}", HttpContext.Current.Request.Url.Scheme, HttpContext.Current.Request.Url.Host, PlaceSeparator(url));
		}
        
		public static string GetSiteUrl(string url)
		{
			if (HttpContext.Current.Request.ApplicationPath.Length > 1)
			{
				url = PlaceSeparator(url);
				url = string.Format("{0}{1}", HttpContext.Current.Request.ApplicationPath, url);
			}
			return GetUrlWithHost(url.Replace("\\", "/"));
		}

    	private static string PlaceSeparator(string url)
    	{
    		if (!string.IsNullOrEmpty(url) && url.Length > 0 && url[0] != '\\' && url[0] != '/')
    			url = '/' + url;
    		return url;
    	}

    	public void GoToSiteItem(string siteID)
		{
			GoToUrl(GetUrl(siteID));
		}

		public void GoToSiteItem(string siteID, params object[] parameters)
		{
			HttpContext.Current.Response.Redirect(GetUrl(siteID, parameters));
		}

		public static void GoToUrl(string url)
		{
			HttpContext.Current.Response.Redirect(url);
		}

    	#region Back Url

    	public static void GoToBackUrl()
    	{
    		string backSiteID = HttpContextHelper.GetString(keyBackUrlItemID);
    		if (!string.IsNullOrEmpty(backSiteID) && Current != null)
    			Current.GoToSiteItem(backSiteID);
    	}

    	private const string keyBackUrlItemID = "BackUrlItemID";

    	#endregion

    }
}