﻿using System;
using System.Security.Cryptography;

namespace outcold.sitemanager.Captcha
{
	public static class CaptchaWord
	{
		public static string GetWord(int lenght)
		{
			RNGCryptoServiceProvider random = new RNGCryptoServiceProvider();
			byte[] bytes = new byte[lenght];
			random.GetBytes(bytes);
			string str = Convert.ToBase64String(bytes);
			return str.Substring(0, Math.Min(str.Length, lenght));
		}
	}
}