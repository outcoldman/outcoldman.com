﻿using System;
using outcold.sitemanager;
using outcold.sitemanager.HTTP;

namespace SampleWebApplication.Pages
{
    /// <summary>
    /// Страница ошибок
    /// </summary>
	public partial class error : UAVDefaultPage
	{
		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);

			int? status = HttpContextHelper.GetInt32("status");

			string msgError = "HTTPErrorUnknow";
			if (status.HasValue)
				msgError = string.Format("HTTPError{0}", status.Value);
			lblError.Text = MessageManager.Current.GetMessage(msgError);
		}
	}
}