﻿function OnDelete() {
	if (confirm('Будет удален объект. Продолжить?')) return true;
	return false;
}