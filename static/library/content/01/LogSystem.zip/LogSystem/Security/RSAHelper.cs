﻿using System.Security.Cryptography;

namespace LogSystem.Security
{
    public class RSAHelper
    {
        static public byte[] Encrypt(byte[] dataToEncrypt, RSAParameters rsaKeyInfo)
        {
            using (RSACryptoServiceProvider rsa = new RSACryptoServiceProvider())
            {
                rsa.ImportParameters(rsaKeyInfo);

                return rsa.Encrypt(dataToEncrypt, false);
            }
        }

        static public byte[] Decrypt(byte[] dataToDecrypt, RSAParameters rsaKeyInfo)
        {
            using (RSACryptoServiceProvider rsa = new RSACryptoServiceProvider())
            {
                rsa.ImportParameters(rsaKeyInfo);

                return rsa.Decrypt(dataToDecrypt, false);
            }
        }
    }
}
