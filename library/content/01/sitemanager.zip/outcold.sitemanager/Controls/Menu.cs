﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;

namespace outcold.sitemanager.Controls
{
    public class Menu : System.Web.UI.WebControls.Menu
    {
        public string MenuID { get; set; }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            MenuClasses.Menu m = MenuManager.Current.GetMenuById(MenuID);
            AddItems(Items, m.Items);
        }

        private static void AddItems(MenuItemCollection collection, IEnumerable<MenuClasses.MenuItem> items)
        {
            foreach (MenuClasses.MenuItem item in items)
            {
                MenuItem child = new MenuItem(item.Title);
                if (!string.IsNullOrEmpty(item.SiteID))
                    child.NavigateUrl = NavigationManager.Current.GetUrl(item.SiteID);
                else
                    child.NavigateUrl = item.Url;
                collection.Add(child);

                if (item.Items != null && item.Items.Length > 0)
                    AddItems(child.ChildItems, item.Items);
            }
        }
    }
}
