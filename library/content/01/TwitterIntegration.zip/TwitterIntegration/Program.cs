﻿using System;
using System.Linq;
using LinqToTwitter;

namespace TwitterIntegration
{
    internal class Program
    {
        private static void Main()
        {
            // Класс, отвечающий за авторизацию
            UsernamePasswordAuthorization auth = new UsernamePasswordAuthorization
                                                     {
                                                         UserName = "UserName",
                                                         Password = "Password"
                                                     };

            // Основной провайдер для работы с twitter
            TwitterContext twitterCtx = new TwitterContext(auth);
            // Осуществляем авторизацию
            auth.SignOn();

            // Берем twit'ы, оставленные нашими друзьями (за кем мы следуем)
            var publicTweets =
                from tweet in twitterCtx.Status
                where tweet.Type == StatusType.Friends
                select tweet;

            // Печатаем результат на экран
            publicTweets.ToList().ForEach(
                tweet => Console.WriteLine(
                             "User Name: {0}, Tweet: {1}", tweet.User.Name, tweet.Text));


            auth.SignOff();

            Console.WriteLine("Press any key to end this demo.");
            Console.ReadKey();
        }
    }
}