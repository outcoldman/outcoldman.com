﻿using System.ServiceModel;
using System.ServiceModel.Channels;

namespace LogSystem.WCF
{
    public static class ServiceHelper
    {
        // TODO: This should be customizing
        public static Binding GetDefaultBinding()
        {
            return new NetTcpBinding();
        }
    }
}