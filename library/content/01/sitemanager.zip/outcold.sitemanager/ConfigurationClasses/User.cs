﻿using System.Xml.Serialization;

namespace outcold.sitemanager.ConfigurationClasses
{
    public class User
    {
        [XmlAttribute]
        public string Name { get; set; }
    }
}