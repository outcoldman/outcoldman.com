﻿using LogSystem.WCF.Server;

namespace LogSystem
{
    /// <summary>
    /// In Future can return not only one instance of Logger 
    /// </summary>
    public static class LoggerFactory
    {
        private static object _lock = new object();

        private static Logger _logger;

        public static ILogger GetLogger()
        {

            if (_logger == null)
            {
                lock (_lock)
                {
                    if (_logger == null)
                    {
                        _logger = new Logger(GetOutputSolution());
                    }
                }
            }
            return _logger;
        }

        private static IOutput GetOutputSolution()
        {
            return WCFOutput.GetOutput();
        }
    }
}
