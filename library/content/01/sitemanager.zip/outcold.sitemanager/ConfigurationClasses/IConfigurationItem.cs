﻿namespace outcold.sitemanager.ConfigurationClasses
{
    internal interface IConfigurationItem
    {
        string Id { get; set; }
    }
}