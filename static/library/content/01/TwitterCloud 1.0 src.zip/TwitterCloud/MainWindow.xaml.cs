﻿using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using TwitterCloud.Model;

namespace TwittCloud
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public MainWindowModel Model
        {
            get { return DataContext as MainWindowModel; }
        }

        public string Version
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }

        private void CreateCloudCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            Model.Progress = 0;
            Model.IsBusy = true;
            Model.Worker.RunWorkerAsync();
        }

        private void CreateCloudCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = !Model.IsBusy
                           && Model.IsValid();
        }

        private void CreateCloudStopCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            Model.Worker.CancelAsync();
        }

        private void CreateCloudStopCommandCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = Model.IsBusy;
        }

        private void HyperlinkCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            Process.Start(((Hyperlink) e.OriginalSource).NavigateUri.AbsoluteUri);
        }

        private void SaveCommandExecute(object sender, ExecutedRoutedEventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog {Filter = "*.png | *.png", FilterIndex = 1};
            if (dlg.ShowDialog(Application.Current.MainWindow).Value)
                SaveToPng(sender as FrameworkElement, dlg.SafeFileName);
        }

        static void SaveToPng(FrameworkElement visual, string fileName)
        {
            var encoder = new PngBitmapEncoder();
            SaveUsingEncoder(visual, fileName, encoder);
        }

        static void SaveUsingEncoder(FrameworkElement visual, string fileName, BitmapEncoder encoder)
        {
            RenderTargetBitmap bitmap = new RenderTargetBitmap(
                (int)visual.ActualWidth,
                (int)visual.ActualHeight,
                96,
                96,
                PixelFormats.Pbgra32);
            bitmap.Render(visual);
            BitmapFrame frame = BitmapFrame.Create(bitmap);
            encoder.Frames.Add(frame);

            using (var stream = File.Create(fileName))
            {
                encoder.Save(stream);
            }
        }
    }
}