﻿using Castle.ActiveRecord;
using outcold.sitemanager.DataAccess;

namespace SampleWebApplication.Domain
{
    /// <summary>
    /// Класс объектов
    /// </summary>
	[ActiveRecord]
	public class Item : HttpActiveRecordBase<Item>
    {
		[PrimaryKey("itemID")]
        public int? ID { get; set; }

		[Property]
        public string Title { get; set; }

		[Property]
        public string Body { get; set; }

		[Property]
        public decimal? Price { get; set; }

		[Property]
        public bool IsActive { get; set; }

		[Property]
        public string ImagePath { get; set; }

		[BelongsTo("categoryID")]
        public Category Category { get; set; }

		[BelongsTo("firmID")]
		public Firm Firm { get; set; }

		[BelongsTo("currencyID")]
		public Currency Currency { get; set; }

		[Property]
		public int? ImgWidth { get; set; }

		[Property]
		public int? ImgHeight { get; set; }
	}
}