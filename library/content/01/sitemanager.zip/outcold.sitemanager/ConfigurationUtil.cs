﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using log4net;
using outcold.sitemanager.Utils;

namespace outcold.sitemanager
{
	public class ConfigurationUtil
	{
		private static readonly ILog Log =
			LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

		public static ConnectionStringSettings ConnectionStringMain
		{
			get { return GetConnectionString(MainConnectionString); }
		}

		public static ConnectionStringSettings GetConnectionString(string connectionStringName)
		{
			ConnectionStringSettings settings = ConnectionStrings[connectionStringName];
			if (settings == null)
			{
				throw
						new InvalidOperationException(
							string.Format("Connection string '{0}' not found!", connectionStringName));
			}
			return settings;
		}

		public static string MainConnectionString
		{
			get { return GetSettings("MainConnectionString", "Main"); }
		}

		#region Hibernate

		public static string HibernateDialect
		{
			get { return GetSettings("hibernate.dialect", "NHibernate.Dialect.MsSql2005Dialect"); }
		}

		public static string HibernateConnectionDriver_class
		{
			get { return GetSettings("hibernate.connection.driver_class", "NHibernate.Driver.SqlClientDriver"); }
		}

		public static string HibernateConnectionProvider
		{
			get { return GetSettings("hibernate.connection.provider", "NHibernate.Connection.DriverConnectionProvider"); }
		}

		#endregion

		#region SiteStat

		public static bool SitestatParseAddData
		{
			get { return GetBoolSettings("Sitestat.ParseAddData", true); }
		}

		public static bool SitestatPersistBots
		{
			get { return GetBoolSettings("Sitestat.PersistBots", true); }
		}

		public static PersistIDPlace SitestatPersistIDPlace
		{
			get { return GetEnumSettings("Sitestat.PersistIDPlace", PersistIDPlace.Session); }
		}

		#endregion

		public static string GetSettings(string name, string defaultValue)
		{
			string result = ConfigurationManager.AppSettings[name];
			if (string.IsNullOrEmpty(result))
				return defaultValue;

			return result;
		}

		public static bool GetBoolSettings(string name, bool defaultValue)
		{
			string result = GetSettings(name, null);
			bool? b = Parser.GetBool(result);
            return (b.HasValue) ? b.Value : defaultValue;
		}

		public static T GetEnumSettings<T>(string name, T defaultValue)
		{
			string value = GetSettings(name, null);

			if (string.IsNullOrEmpty(value))
				return defaultValue;

			try
			{
				return (T)Enum.Parse(typeof(T), value);
			}
			catch (Exception ex)
			{
				if (Log.IsErrorEnabled)
				{
					string message = string.Format(
						"Failed to parse configured value '{1}' for {0}." +
						" Using {2} as default value.", name, value, defaultValue);
					Log.Error(message, ex);
				}
				return defaultValue;
			}
		}

		private static ConnectionStringSettingsCollection ConnectionStrings
		{
			get { return ConfigurationManager.ConnectionStrings; }
		}
	}
}
