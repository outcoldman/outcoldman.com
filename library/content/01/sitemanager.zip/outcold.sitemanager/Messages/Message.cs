﻿using System.Xml.Serialization;

namespace outcold.sitemanager.Messages
{
	public sealed class Message
	{
		[XmlAttribute]
		public string Name { get; set; }

		[XmlAttribute]
		public string Value { get; set; }
	}
}