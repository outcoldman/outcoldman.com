﻿namespace LogSystem
{
    internal interface IOutput
    {
        void PutMessage(string msg);
    }
}