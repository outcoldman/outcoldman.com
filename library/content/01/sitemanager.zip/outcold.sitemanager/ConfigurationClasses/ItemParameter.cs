﻿using System.Xml.Serialization;

namespace outcold.sitemanager.ConfigurationClasses
{
	public class ItemParameter
	{
		[XmlAttribute]
		public string Name { get; set; }

		[XmlAttribute]
		public string Value { get; set; }
	}
}
