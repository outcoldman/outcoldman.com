﻿using System.Xml.Serialization;

namespace outcold.sitemanager.Statistic
{
	public sealed class SearchEngines
	{
		[XmlElement("SearchEngine")]
		public SearchEngine[] List { get; set; }
	}

	public sealed class SearchEngine
	{
		[XmlAttribute]
		public string Name { get; set; }

		[XmlAttribute]
		public string Mask { get; set; }

		[XmlAttribute]
		public string KeywordsMask { get; set; }

		[XmlAttribute]
		public int ID { get; set; }
	}
}