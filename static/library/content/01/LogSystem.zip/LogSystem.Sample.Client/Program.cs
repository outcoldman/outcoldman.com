﻿using System;
using LogSystem.WCF.Client;

namespace LogSystem.Sample.Client
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            if (args.Length > 0 && (args[0] == "help" || args[0] == "/?" || args[0] == "/h"))
            {
                Console.WriteLine("type -s to use secure connection");
                return;
            }

            bool isSecure = args.Length > 0 && args[0] == "-s";

            using (WCFListener listener = new WCFListener("net.tcp://localhost:2222/Logger/", isSecure))
            {
                listener.Log += ListenerLog;

                Console.WriteLine("Press escape to exit.");

                while (Console.ReadKey().Key != ConsoleKey.Escape)
                {
                    // Listen
                }
            }
        }

        private static void ListenerLog(string obj)
        {
            Console.WriteLine(obj);
        }
    }
}