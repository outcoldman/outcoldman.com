﻿using System;
using System.Web.Security;
using System.Web.UI.WebControls;

namespace SampleWebApplication.Pages
{
    /// <summary>
    /// Страница аутентификации
    /// </summary>
	public partial class AdminLogin : UAVDefaultPage
	{
		protected void OnAuthenticate(object sender, AuthenticateEventArgs e)
		{
			e.Authenticated = FormsAuthentication.Authenticate(lgnCtl.UserName, lgnCtl.Password);
		}

		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);
			divLogin.Visible = Request.IsAuthenticated;
			divCtlLogin.Visible = lgnCtl.Visible = !Request.IsAuthenticated;
		}
	}
}