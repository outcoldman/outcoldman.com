﻿using System.Xml.Serialization;

namespace outcold.sitemanager.MenuClasses
{
    [XmlRoot(Namespace = "outcold.sitemenu")]
    public sealed class Menus
    {
        [XmlElement("Menu")]
        public Menu[] Items { get; set; }
    }
}