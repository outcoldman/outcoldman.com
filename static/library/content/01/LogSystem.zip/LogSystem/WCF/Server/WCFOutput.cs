﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Threading;

namespace LogSystem.WCF.Server
{
    internal class WCFOutput : IOutput, IDisposable
    {
        private ServiceHost _host;

        private object _stackLocker = new object();
        private readonly Queue<string> _queue = new Queue<string>();
        private readonly Timer _timer ;

        private WCFOutput()
        {
            _timer = new Timer(OnTimerLogger);
            LaunchTimer();
        }

        #region Static, singlton

        private static readonly object _locker = new object();

        private static WCFOutput _output;

        public static IOutput GetOutput()
        {
            if (_output == null)
            {
                lock (_locker)
                {
                    if (_output == null)
                    {
                        _output = new WCFOutput();
                        _output.OpenHost();
                    }
                }
            }
            return _output;
        }

        #endregion

        #region WCF implementation

        ~WCFOutput()
        {
            Dispose();
        }

        public void Dispose()
        {
            CloseHost();
        }
        
        private void OpenHost()
        {
            CloseHost();

            _host = new ServiceHost(typeof(WCFLoggerOutputService));

            // TODO: Url param must be customize
            _host.AddServiceEndpoint(typeof(IWCFLoggerOutput), ServiceHelper.GetDefaultBinding()
                                     , "net.tcp://localhost:2222/Logger/");
            _host.Open();
        }

        private void CloseHost()
        {
            if (_host != null)
            {
                _host.Close();
                _host = null;
            }
        }

        #endregion

        #region Register client listeners

        private static object _eventLocker = new object();

        public delegate bool LoggerAction(string message);

        private static event LoggerAction OnLog;

        public static void RegisterOnLog(LoggerAction action)
        {
            lock (_eventLocker)
            {
                OnLog += action;
            }
        }

        public static void UnRegisterOnLog(LoggerAction action)
        {
            lock (_eventLocker)
            {
                OnLog -= action;
            }
        }

        #endregion

        #region IOutput interface

        //TODO: Write thread safe queue wih unlimited write and limited read
        public void PutMessage(string msg)
        {
            lock (_stackLocker)
            {
                _queue.Enqueue(msg);
            }
        }

        #endregion

        private void OnTimerLogger(object obj)
        {
            while (ContainsLogs())
            {
                string msg = GetNextMsg();

                lock (_eventLocker)
                {
                    if (OnLog != null)
                    {
                        IList<LoggerAction> badDelegates = new List<LoggerAction>();

                        foreach (LoggerAction action in OnLog.GetInvocationList())
                        {
                            try
                            {
                                if (!action(msg))
                                {
                                    badDelegates.Add(action);
                                }
                            }
                            //TODO: use log4net to log this error
                            catch (Exception)
                            {
                                badDelegates.Add(action);
                            }
                        }

                        foreach (var action in badDelegates)
                        {
                            OnLog -= action;
                        }
                    }
                }
            }

            LaunchTimer();
        }

        private string GetNextMsg()
        {
            lock (_stackLocker)
            {
                return _queue.Dequeue();
            }
        }

        private bool ContainsLogs()
        {
            lock (_stackLocker)
            {
                return _queue.Count > 0;
            }
        }

        private void LaunchTimer()
        {
            _timer.Change(100, Timeout.Infinite);
        }
    }
}