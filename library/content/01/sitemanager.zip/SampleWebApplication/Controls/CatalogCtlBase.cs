﻿using System.Web.UI;
using outcold.sitemanager;
using outcold.sitemanager.HTTP;
using SampleWebApplication.Domain;

namespace SampleWebApplication.Controls
{
	public class CatalogCtlBase : UserControl
	{
		private int? _firmID;

		protected int? FirmID
		{
			get
			{
				if (!_firmID.HasValue)
				{
					_firmID = HttpContextHelper.GetInt32("firmID");
				}
				return _firmID;
			}
		}

		private int? _categoryID;

		protected int? CategoryID
		{
			get
			{
				if (!_categoryID.HasValue)
				{
					_categoryID = HttpContextHelper.GetInt32("categoryID");
				}
				return _categoryID;
			}
		}

		protected string GetCategoryUrl(int categoryID)
		{
			return FirmID.HasValue && FirmID.Value > 0
			       	? NavigationManager.Current.GetUrl("SampleWebApplication.catalog.firm.category", FirmID.Value, categoryID)
			       	: NavigationManager.Current.GetUrl("SampleWebApplication.catalog.category", categoryID);
		}

		private Firm _firm;

		protected Firm Firm
		{
			get
			{
				if (_firm == null && FirmID.HasValue)
				{
					_firm = Firm.Find(FirmID.Value);
				}
				return _firm;
			}
		}
	}
}