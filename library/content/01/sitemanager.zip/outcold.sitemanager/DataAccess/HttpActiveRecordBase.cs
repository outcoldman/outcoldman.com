﻿using System.Web;
using Castle.ActiveRecord;

namespace outcold.sitemanager.DataAccess
{
	public abstract class HttpActiveRecordBase<T> : ActiveRecordBase<T>
	{
		public static T Find(int id)
		{
			try
			{
				return ActiveRecordBase<T>.Find(id);
			}
			catch(NotFoundException exp)
			{
				Log4NetHelper.Log.Error(exp);
				throw new HttpException(404, "Page not find");
			}
		}
	}
}
