﻿using System.Web.UI;
using System.Web.UI.WebControls;

namespace SampleWebApplication.Controls
{
	public partial class UAVFCKEditor : UserControl
	{
		private const string constBasicToolBarName = "Basic";
		private const string constDefaultToolBarName = "Default";

		public bool ShortToolbar
		{
			set { fckEditor.ToolbarSet = value ? constBasicToolBarName : constDefaultToolBarName; }
			get { return string.Compare(fckEditor.ToolbarSet, constBasicToolBarName) == 0; }
		}

		public Unit Width
		{
			set { fckEditor.Width = value; }
			get { return fckEditor.Width; }
		}

		public Unit Height
		{
			set { fckEditor.Height = value; }
			get { return fckEditor.Height; }
		}

		public string Value
		{
			set { fckEditor.Value = value; }
			get { return fckEditor.Value; }
		}
	}
}