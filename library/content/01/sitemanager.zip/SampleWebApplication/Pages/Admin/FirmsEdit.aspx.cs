﻿using System;
using System.IO;
using System.Web.UI;
using outcold.sitemanager;
using outcold.sitemanager.HTTP;
using SampleWebApplication.Domain;

namespace SampleWebApplication.Pages.Admin
{
    /// <summary>
    /// Страница редактирования фирмы
    /// </summary>
	public partial class FirmsEdit : UAVDefaultPage
	{
		private int? _id;

		protected int? FirmID
		{
			get
			{
				if (!_id.HasValue)
				{
					_id = HttpContextHelper.GetInt32("id");
				}
				return _id;
			}
		}

		private Firm _firm;

		protected Firm Firm
		{
			get
			{
				if (_firm == null && FirmID.HasValue)
				{
					_firm = Firm.Find(FirmID.Value);
				}
				return _firm;
			}
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			if (!IsPostBack)
			{
				InitFirm();
			}

			btnDelete.Visible = FirmID.HasValue;

			lblError.Text = MessageManager.Current.GetMessage("CannotDeleteRecord");
			lblError.Visible = false;
		}

		private void InitFirm()
		{
			if (FirmID.HasValue && Firm != null)
			{
				tbTitle.Text = Firm.Name;
				tbFirmUrl.Text = Firm.Url;
				chkIsActive.Checked = Firm.IsActive;
				hiddenImgPath.Value = Firm.ImagePath;
				imgItem.Src = NavigationManager.GetSiteUrl(Firm.ImagePath);
				imgItem.Visible = !string.IsNullOrEmpty(Firm.ImagePath);
				btnDelImage.Visible = !string.IsNullOrEmpty(Firm.ImagePath);
			}
		}

		protected void btnSave_Click(object sender, EventArgs e)
		{
			bool isActive = chkIsActive.Checked;
			string titile = tbTitle.Text;
			string url = tbFirmUrl.Text;

			if (!imgItem.Visible && !string.IsNullOrEmpty(hiddenImgPath.Value))
			{
				FileManager.DeleteFile(hiddenImgPath.Value);
				hiddenImgPath.Value = null;
			}

			string imgPath = uploadImg.HasFile
								? FileManager.SaveGuidFile(MessageManager.Current.GetMessage("ImageFirmsPath")
															 , Path.GetExtension(uploadImg.FileName), uploadImg.FileBytes)
								: hiddenImgPath.Value;
			if (uploadImg.HasFile && !string.IsNullOrEmpty(hiddenImgPath.Value))
				FileManager.DeleteFile(hiddenImgPath.Value);

			Firm firm = FirmID.HasValue ? Firm.Find(FirmID.Value) : new Firm();
			firm.ImagePath = imgPath;
			firm.Url = url;
			firm.IsActive = isActive;
			firm.Name = titile;
			firm.Save();
		}

		protected void btnDelete_Click(object sender, EventArgs e)
		{
			if (FirmID.HasValue)
			{
				try
				{
					Firm firm = Firm.Find(FirmID.Value);
					FileManager.DeleteFile(firm.ImagePath);
					firm.DeleteAndFlush();
					NavigationManager.GoToBackUrl();
				}
				catch(Exception exp)
				{
					Log4NetHelper.Log.Error(exp);
					lblError.Visible = true;
				}
			}
		}

		protected void btnDelImage_Click(object sender, ImageClickEventArgs e)
		{
			if (!string.IsNullOrEmpty(hiddenImgPath.Value))
			{
				imgItem.Visible = false;
				btnDelImage.Visible = false;
			}
		}
	}
}