﻿using System;
using System.Security.Cryptography.Pkcs;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Web.UI;

namespace CertificateWebExample
{
    public partial class _Default : Page
    {
        protected void btnSignData_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();

            // Смотрим, что подписано
            SignedCms cms = new SignedCms();
            cms.Decode(Convert.FromBase64String(tbSignedData.Text));
            // Проверяем подпись
            cms.CheckSignature(false);

            // Что подписано
            sb.AppendLine(Encoding.Unicode.GetString(cms.ContentInfo.Content));

            //Сравним сертификат, которым были подписаны данные, и клиентский сертификат 
            if (Request.IsSecureConnection && Request.ClientCertificate.IsPresent)
            {
                X509Certificate2 cert = new X509Certificate2(Request.ClientCertificate.Certificate);
                if (cms.SignerInfos.Count > 0 &&
                    string.Compare(cms.SignerInfos[0].Certificate.SerialNumber, cert.SerialNumber) == 0
                    && string.Compare(cms.SignerInfos[0].Certificate.Issuer, cert.Issuer) == 0)
                {
                    sb.AppendLine("<br/>Данные подписаны клиентским сертификатом");
                }
                else
                {
                    sb.AppendLine("<br/>Данные подписаны отличным от клиентского сертификатом");
                }
            }

            lblData.Text = sb.ToString();
        }
    }
}
