﻿namespace TwitterCloud.Model
{
    public class TopWord
    {
        public string Word { get; set; }
        public int Count { get; set; }
    }
}