﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Serialization;

namespace outcold.sitemanager.ConfigurationClasses
{
    [XmlRoot(Namespace = "outcold.sitemanagerconfiguration")]
    public sealed class Configuration : SiteItemsContainerBase
    {
        [XmlAttribute]
        public string Extension { get; set; }

        [XmlAttribute]
        public string Separator { get; set; }
        
        internal SiteItem GetItem(string url)
        {
            if (!string.IsNullOrEmpty(Extension))
            {
                if (!IsExtension(url))
                    return null;

                url = url.Substring(0, url.Length - Extension.Length);
            }

            string[] steps = url.Split(new []{Separator}, StringSplitOptions.RemoveEmptyEntries);

            int step = 0;

            return GetItem(steps, step);
        }

        public bool IsExtension(string url)
        {
        	return !string.IsNullOrEmpty(Extension) && Regex.IsMatch(url, string.Format("{0}$", Extension));
        }

        public string GetUrlById(string itemid, params object[] parameters)
        {
            StringBuilder builder = new StringBuilder();
            int parametersCount = 0;
            SiteItem item = GetItemById(itemid, ref builder, ref parametersCount);
            if (item != null && parameters.Length == parametersCount)
                return string.Format(builder.ToString(), Invert(parameters));
            return null;
        }

        private object[] Invert(object[] parameters)
        {
            object[] inverted = new object[parameters.Length];
            for (int i = 0; i < parameters.Length; i++)
                inverted[parameters.Length - 1 - i] = parameters[i];
            return inverted;
        }

		public bool CheckUser(string itemid)
		{
			if (!IsUserAllowed())
				return false;

			return IsUserAllowed(itemid);
		}
    }
}