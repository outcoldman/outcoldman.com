﻿using System.Collections;
using System.Reflection;
using System.Web;
using Castle.ActiveRecord;
using Castle.ActiveRecord.Framework;
using Castle.ActiveRecord.Framework.Config;

namespace outcold.sitemanager.DataAccess
{
	public class ActiveRecordManager
	{
		private static readonly IConfigurationSource _source;

		static ActiveRecordManager()
		{
			Hashtable properties = new Hashtable
			                       	{
			                       		{"hibernate.connection.provider", ConfigurationUtil.HibernateConnectionProvider},
			                       		{"hibernate.connection.driver_class", ConfigurationUtil.HibernateConnectionDriver_class},
			                       		{"hibernate.dialect", ConfigurationUtil.HibernateDialect},
			                       		{
			                       			"hibernate.connection.connection_string",
			                       			(ConfigurationUtil.ConnectionStringMain == null)
			                       				? null
			                       				: ConfigurationUtil.ConnectionStringMain.ConnectionString
			                       			}
			                       	};
			InPlaceConfigurationSource source = new InPlaceConfigurationSource
			                                    	{
			                                    		IsRunningInWebApp = (HttpContext.Current != null)
			                                    	};
			source.Add(typeof(ActiveRecordBase), properties);
			_source = source;
		}

		public static bool Initialized { get; set;}

		public static void Initialize(params Assembly[] assemblies)
		{
			ActiveRecordStarter.Initialize(assemblies, _source);
			Initialized = true;
		}
	}
}
