﻿using System.Xml.Serialization;

namespace outcold.sitemanager.MenuClasses
{
    public class Menu
    {
        [XmlAttribute]
        public string Id { get; set; }

        [XmlElement("MenuItem")]
        public MenuItem[] Items { get; set; }
    }
}