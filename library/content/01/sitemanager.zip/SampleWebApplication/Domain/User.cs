﻿using System.Web;

namespace SampleWebApplication.Domain
{
    /// <summary>
    /// Информация о пользователе
    /// </summary>
	public static class User
	{
		public static bool IsAdmin
		{
			get
			{
				return HttpContext.Current != null && HttpContext.Current.User != null
				       && HttpContext.Current.Request.IsAuthenticated
				       && (string.Compare(HttpContext.Current.User.Identity.Name, "admin") == 0);
			}
		}
	}
}