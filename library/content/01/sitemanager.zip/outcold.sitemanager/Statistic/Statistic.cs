﻿using System.Xml.Serialization;

namespace outcold.sitemanager.Statistic
{
	[XmlRoot(Namespace = "outcold.sitestatistic")]
	public sealed class Statistic
	{
		[XmlElement]
		public SearchEngines SearchEngines { get; set; }

		[XmlElement]
		public Bots Bots { get; set; }
	}
}