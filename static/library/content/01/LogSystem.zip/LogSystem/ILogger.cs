﻿namespace LogSystem
{
    /// <summary>
    /// Default logger
    /// In this version just one method Log
    /// </summary>
    public interface ILogger
    {
        void Log(string msg);
    }
}
