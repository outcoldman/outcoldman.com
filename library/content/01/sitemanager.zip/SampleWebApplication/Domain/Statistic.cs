﻿using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;

namespace SampleWebApplication.Domain
{
    /// <summary>
    /// Класс для работы со статистикой страницы
    /// </summary>
	public class Statistic
	{
		public static string GetHtmlStatistic()
		{
			if (!User.IsAdmin)
				return null;

			string page = HttpContext.Current.Request.AppRelativeCurrentExecutionFilePath.Length > 2
			              	? HttpContext.Current.Request.AppRelativeCurrentExecutionFilePath.Substring(2)
			              	: HttpContext.Current.Request.AppRelativeCurrentExecutionFilePath;

			int countPage = 0,
				   countItem = 0,
				   countSession = 0,
				   countPageB = 0,
				   countItemB = 0,
				   countSessionB = 0;

			using(SqlConnection connection = new SqlConnection(DataAccessor.SqlConnection.ConnectionString))
			{
				using (SqlCommand command = new SqlCommand("GetPageStatistic", connection) { CommandType = CommandType.StoredProcedure })
				{
					command.Parameters.AddWithValue("@page", page);
					connection.Open();
					using (SqlDataReader reader = command.ExecuteReader())
					{
						if (reader != null && reader.Read())
						{
							countPage = reader.GetInt32(0);
							countItem = reader.GetInt32(1);
							countSession = reader.GetInt32(2);
							countPageB = reader.GetInt32(3);
							countItemB = reader.GetInt32(4);
							countSessionB = reader.GetInt32(5);
						}
					}
				}
			}

			StringBuilder sb = new StringBuilder();
			sb.AppendFormat("<p><b>Статистика:</b></p>");
			sb.AppendFormat("<p>Количество просмотров страницы - {0}</p>", countPage);
			if (countItem > 0)
				sb.AppendFormat("<p>Количество просмотров продукта - {0}</p>", countItem);
			sb.AppendFormat("<p>Количество просмотров страницы в разных сессиях - {0}</p>", countSession);
			sb.AppendFormat("<p>Количество просмотров страницы(Учитывая ботов) - {0}</p>", countPageB);
			if (countItem > 0)
				sb.AppendFormat("<p>Количество просмотров продукта(Учитывая ботов) - {0}</p>", countItemB);
			sb.AppendFormat("<p>Количество просмотров страницы в разных сессиях(Учитывая ботов) - {0}</p>", countSessionB);
			return sb.ToString();
		}

		public static void ClearStatistic()
		{
			using (SqlConnection connection = new SqlConnection(DataAccessor.SqlConnection.ConnectionString))
			{
				using (
					SqlCommand command = new SqlCommand("ClearStatistic", connection) { CommandType = CommandType.StoredProcedure })
				{
					connection.Open();
					command.ExecuteNonQuery();
				}
			}
		}
	}
}
