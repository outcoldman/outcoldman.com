﻿using System;
using System.IO;
using System.Xml.Serialization;
using outcold.sitemanager.Messages;

namespace outcold.sitemanager
{
	public sealed class MessageManager
	{
		private const string _key = "MessageConfiguration";

		private static Messages.Messages GetConfiguration(string location)
		{
			Log4NetHelper.Log.InfoFormat("Load Menus: {0}", location);
			using (FileStream stream = new FileStream(location, FileMode.Open, FileAccess.Read))
			{
				XmlSerializer serializer = new XmlSerializer(typeof (Messages.Messages));
				object obj = serializer.Deserialize(stream);
				return obj as Messages.Messages;
			}
		}

		private static Messages.Messages GetConfiguration()
		{
			string location = System.Configuration.ConfigurationManager.AppSettings.Get(_key);
			return GetConfiguration(AppDomain.CurrentDomain.BaseDirectory + location);
		}

		public string GetMessage(string name)
		{
			foreach (Message m in Messages.List)
			{
				if (string.Compare(m.Name, name) == 0)
					return m.Value;
			}
			return null;
		}

		#region Singleton

		private static readonly object _locker = new object();
		private static MessageManager _current;

		private MessageManager(Messages.Messages menus)
		{
			Messages = menus;
		}

		public static MessageManager Current
		{
			get
			{
				if (_current == null)
				{
					lock (_locker)
					{
						if (_current == null)
						{
							_current = new MessageManager(GetConfiguration());
						}
					}
				}
				return _current;
			}
		}

		internal Messages.Messages Messages { get; set; }

		public static MessageManager Init(MessageManager current)
		{
			if (_current == null)
			{
				lock (_locker)
				{
					if (_current == null)
					{
						_current = current;
					}
				}
			}
			return _current;
		}

		#endregion
	}
}