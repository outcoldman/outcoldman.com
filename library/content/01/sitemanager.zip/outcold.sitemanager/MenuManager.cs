﻿using System;
using System.IO;
using System.Xml.Serialization;
using outcold.sitemanager.MenuClasses;

namespace outcold.sitemanager
{
    internal class MenuManager
    {
        private const string _key = "MenuConfiguration";

        public static Menus GetConfiguration(string location)
        {
            Log4NetHelper.Log.InfoFormat("Load Menus: {0}", location);
            using (FileStream stream = new FileStream(location, FileMode.Open, FileAccess.Read))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(Menus));
                object obj = serializer.Deserialize(stream);
                return obj as Menus;
            }
        }

        public static Menus GetConfiguration()
        {
            string location = System.Configuration.ConfigurationManager.AppSettings.Get(_key);
            return GetConfiguration(AppDomain.CurrentDomain.BaseDirectory + location);
        }

        #region Singleton

        private static MenuManager _current;
        private static object _locker = new object();

		public static MenuManager Current
		{
			get
			{
				if (_current == null)
				{
					lock (_locker)
					{
						if (_current == null)
						{
							_current = new MenuManager(GetConfiguration());
						}
					}
				}
				return _current;
			}
		}

        public static MenuManager Init(MenuManager current)
        {
            if (_current == null)
            {
                lock (_locker)
                {
                    if (_current == null)
                    {
                        _current = current;
                    }
                }
            }
            return _current;
        }

        private MenuManager(Menus menus)
        {
            Menus = menus;
        }

        internal Menus Menus { get; set;}

        #endregion

        public Menu GetMenuById(string id)
        {
            foreach (Menu m in Menus.Items)
            {
                if (string.Compare(m.Id, id) == 0)
                    return m;
            }
            return null;
        }
    }
}