﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Xml.Serialization;

namespace outcold.sitemanager.ConfigurationClasses
{
    public abstract class SiteItemsContainerBase : ConfigurationItemBase
    {
        [XmlElement("Item")]
        public SiteItem[] Items { get; set; }

        [XmlElement("Folder")]
        public SiteFolder[] Folders { get; set; }

        protected SiteItem GetItem(string[] steps, int step)
        {
            string strStep = steps[step];
            if (steps.Length > step + 1)
            {
				if (Folders != null)
				{
					foreach (SiteFolder siteFolder in Folders)
					{
						if (Regex.IsMatch(strStep, string.Format("{0}$", siteFolder.Pattern), RegexOptions.IgnoreCase))
						{
							SaveParameters(strStep, siteFolder);
							return siteFolder.GetItem(steps, ++step);
						}
					}
				}
            }
            else if (steps.Length == step + 1)
            {
				if (Items != null)
				{
					foreach (SiteItem item in Items)
					{
						SaveParameters(strStep, item);
						if (Regex.IsMatch(strStep, item.Pattern, RegexOptions.IgnoreCase))
							return item;
					}
				}
            }
            return null;
        }

		private static void SaveParameters(string strStep, IPatternItem item)
        {
			if (item.ContextParameter != null)
			{
				object parameter = null;
				switch (item.ContextParameter.DataType)
				{
					case ParameterDataType.integer:
						{
							int iParameter;
							if (int.TryParse(strStep, out iParameter))
							{
								parameter = iParameter;
							}
							break;
						}
					case ParameterDataType.literal:
						{
							parameter = strStep;
							break;
						}
				}
				HttpContext.Current.Items[item.ContextParameter.Name] = parameter;
			}
			if (item.Parameters != null)
			{
				foreach (ItemParameter parameter in item.Parameters)
				{
					HttpContext.Current.Items[parameter.Name] = parameter.Value;
				}
			}
        }

        protected SiteItem GetItemById(string itemid, ref StringBuilder builder, ref int parametersCount)
        {
            if (string.IsNullOrEmpty(itemid))
                throw new NullReferenceException("itemid");

            if (builder == null)
                throw new NullReferenceException("builder");

            Configuration configuration = NavigationManager.Current.Configuration;

            if (Items != null)
            {
                foreach (SiteItem siteItem in Items)
                {
                    if (string.Compare(siteItem.Id, itemid) == 0)
                    {
                        builder.AppendFormat("{0}{1}{2}", configuration.Separator,
                                             GetUrlPattern(siteItem, ref parametersCount), configuration.Extension);
                        return siteItem;
                    }
                }
            }

            if (Folders != null)
            {
                foreach (SiteFolder folder in Folders)
                {
                    SiteItem item = folder.GetItemById(itemid, ref builder, ref parametersCount);
                    if (item != null)
                    {
                        builder.Insert(0,
                                       string.Format("{0}{1}", configuration.Separator,
                                                     GetUrlPattern(folder, ref parametersCount)));
                        return item;
                    }
                }
            }

            return null;
        }

		protected bool IsUserAllowed(string itemid)
		{
			if (string.IsNullOrEmpty(itemid))
				return true;

			if (Items != null)
			{
				foreach (SiteItem siteItem in Items)
				{
					if (string.Compare(siteItem.Id, itemid) == 0)
					{
						return IsUserAllowed();
					}
				}
			}

			if (Folders != null)
			{
				foreach (SiteFolder folder in Folders)
				{
					bool isAllowed = folder.IsUserAllowed(itemid);
					if (isAllowed)
					{
						return IsUserAllowed();
					}
				}
			}

			return false;
		}

        private static string GetUrlPattern(IPatternItem item, ref int parametersCount)
        {
            if (item == null)
                throw new NullReferenceException("item");

			if (item.ContextParameter != null)
            {
                return string.Format("{{{0}}}", parametersCount++);
            }

            return item.Pattern;
        }
    }
}
